<script>
    $('.card-deck a').fancybox({
        caption: function (instance, item) {
            return $(this).parent().find('.card-text').html();
        }
    });
</script>
<style>
    .d-block {
        display: block
    }

    .modal.fade.in {
        max-width: 100% !important;
        position: fixed;
        display: block;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
        height: 100%;
        box-shadow: none;
        background: #21212187;
    }

    .modal-backdrop {
        display: none !important;
    }

    .modal-box {
        display: none;
        position: fixed;
        z-index: 1000;
        width: 98%;
        background: white;
        border-bottom: 1px solid #aaa;
        border-radius: 4px;
        box-shadow: 0 3px 9px rgba(0, 0, 0, 0.5);
        border: 1px solid rgba(0, 0, 0, 0.1);
        background-clip: padding-box;
        top: 50% !important;
        left: 50% !important;
        transform: translate(-50%, -50%);
    }

    .modal-box header,
    .modal-box .modal-header {
        padding: 1.25em 1.5em;
        border-bottom: 1px solid #ddd;
    }

    .modal-box header h3,
    .modal-box header h4,
    .modal-box .modal-header h3,
    .modal-box .modal-header h4 {
        margin: 0;
    }

    a, button {
        transition: all .3s ease
    }

    a:hover, button:hover {
        opacity: .75;
    }

    .bottom_btns {
        padding: 14px !important;
        border-block: 1px solid #d4d4d4 !important;
        margin-top: 12px;
        margin-bottom: 28px;
        display: flex !important;
        justify-content: space-between;
        align-items: center;
    }

    .enquire-btn {
        padding: 11.5px 25.0563px 12.5px 25.2406px;
        background: #E6542D;
        border-radius: 2px;
        font-weight: 700;
        font-size: 14px;
        line-height: 16px;
        border: 0px;
        text-align: center;
        text-transform: capitalize;
        color: #FFFFFF;
        display: inline-block;
        float: right;
    }

    .modal-box .modal-body {
        padding: 0;
        padding: 2em;
    }

    .modal-box footer,
    .modal-box .modal-footer {
        padding: 1em;
        border-top: 1px solid #ddd;
        background: rgba(0, 0, 0, 0.02);
        text-align: right;
    }

    .modal-overlay {
        opacity: 0;
        filter: alpha(opacity=0);
        position: fixed;
        top: 0;
        left: 0;
        z-index: 0999;
        width: 100%;
        height: 100%;
        background: black;
    }

    a.close {
        line-height: 1;
        font-size: 1.5em;
        position: absolute;
        top: 5%;
        right: 2%;
        text-decoration: none;
        color: #bbb;
    }

    a.close:hover {
        color: #222;
        -webkit-transition: color 1s ease;
        -moz-transition: color 1s ease;
        transition: color 1s ease;
    }

    @media (min-width: 32em) {
        .modal-box {
            width: 70%;
        }
    }
</style>
<footer class="footer">
    <div class="container-fluid nopad">
        <ul class="tabbed">
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">Domestic Tour Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/tour-packages/shimla">Shimla Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/manali">Manali Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/gangtok">Gangtok Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/north-east">North East Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/ladakh">Ladakh Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/darjeeling">Darjeeling Tour Packages</a>
                    </li>
                </ul>
            </li>
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">Domestic Honeymoon Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/honeymoon-packages/shimla">Shimla Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/manali">Manali Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/gangtok">Gangtok Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/ooty">Ooty Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/coorg">Coorg Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/darjeeling">Darjeeling Honeymoon Packages</a>
                    </li>
                </ul>
            </li>
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">International Tour Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/tour-packages/bangkok">Bangkok Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/spain">Spain Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/london">London Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/paris">Paris Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/italy">Italy Tour Packages</a>
                    </li>
                    <li>
                        <a href="/tour-packages/turkey">Turkey Tour Packages</a>
                    </li>
                </ul>

            </li>
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">International Honeymoon Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/honeymoon-packages/bangkok">Bangkok Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/pattaya">Pattaya Honeymoon Packages </a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/london">London Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/paris">Paris Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/italy">Italy Honeymoon Packages</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/phuket">Phuket Honeymoon Packages</a>
                    </li>
                </ul>

            </li>
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">International Honeymoon Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/tour-packages/from-delhi">Tour Packages From Delhi</a>
                    </li>
                    <li>
                        <a href="/tour-packages/from-mumbai">Tour Packages From Mumbai</a>
                    </li>
                    <li>
                        <a href="/tour-packages/from-chennai">Tour Packages From Chennai</a>
                    </li>
                    <li>
                        <a href="/tour-packages/from-kolkata">Tour Packages From Kolkata</a>
                    </li>
                    <li>
                        <a href="/tour-packages/from-bangalore">Tour Packages From Bangalore</a>
                    </li>
                    <li>
                        <a href="/tour-packages/from-hyderabad">Tour Packages From Hyderabad</a>
                    </li>
                </ul>

            </li>
            <li class="tabbed-data static fw7 sfcw m0 f14 p15 LabelSeoLinks has-sub">
                <a href="#">Popular Honeymoon Packages</a>
                <ul class="InlineList">
                    <li>
                        <a href="/honeymoon-packages/from-delhi">Honeymoon Packages From Delhi</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/from-mumbai">Honeymoon Packages From Mumbai</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/from-chennai">Honeymoon Packages From Chennai</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/from-bangalore">Honeymoon Packages From Bangalore</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/from-hyderabad">Honeymoon Packages From Hyderabad</a>
                    </li>
                    <li>
                        <a href="/honeymoon-packages/from-pune">Honeymoon Packages From Pune</a>
                    </li>
                </ul>
            </li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-8 nopad">
                <ul class="menu menu2">
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/aboutus">About Us</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/team">Team</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/career">We are hiring!</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/testimonials">Testimonial</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="" href="/blog/">Blog</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="#">Dopamine
                            Travelogues</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/tnc">Terms and
                            Conditions</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/privacy">Privacy Policy</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow"
                           href="/online-leads-for-travel-agents">Travel Agent? Join Us</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/FAQs">FAQ</a>
                    </li>
                    <li class="mb8 mr15">
                        <a class="m0 p0 f12 SFCW tdn at_footer_link" rel="nofollow" href="/contact_us">Contact Us</a>
                    </li>
                </ul>
            </div>
            <div class="col-sm-4 phone_mail">
                <p class="pull-right text-right"><a href="tel:1800 123 5555"><i class="fa fa-phone"></i> 800 123
                        000</a></p>
                <p class="pull-right text-right"><a href="mailto:customercare@dopaminetravel.com"><i
                                class="fa fa-envelope-o"></i> customercare@dopaminetravel.com</a></p>
            </div>
        </div>
        <div class="row office_address_etc">
            <div class="col-sm-4">
                <p><strong>Corporate Office:</strong><br>

                    Dopamine Travel Private Limited<br>

                    Address: Suite No - 121 , 2nd Floor,<br>

                    UAE<br>

                    Landline: 800 123 000</p>
            </div>
            <div class="col-sm-4">
                <p><strong>Connect with us on :</strong></p>
                <div class="social_icons">
                    <a class="_3_Tox7G _3zRbT39" href="#" target="_blank" rel="nofollow">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a class="_3_Tox7G _18a115F" href="#" target="_blank" rel="nofollow">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a class="_3_Tox7G _9OO8JwO" href="#" target="_blank" rel="nofollow">
                        <i class="fa fa-pinterest"></i>
                    </a>
                    <a class="_3_Tox7G _3WFLcWA" href="#" target="_blank" rel="nofollow">
                        <i class="fa fa-plus.google"></i>
                    </a>
                    <a class="_3_Tox7G _2BHRlzc" href="#" target="_blank" rel="nofollow">
                        <i class="fa fa-instagram"></i>
                    </a>
                </div>
            </div>
        </div>
        <div class="row copy_row">
            <div class="col-sm-4 text-left"><img src="{{ asset('travel/images/paymentoptions.png') }}"></div>
            <div class="col-sm-4 text-center">Made with <i class="fa fa-heart"></i> in UAE</div>
            <div class="col-sm-4 text-right">All rights reserved © 2023</div>
        </div>
    </div>
</footer>
<div class="container form_container">
    <div class="close_form_popup" id="close">
        X
    </div>
    <form action="{{ url('help-planning') }}" method="POST" id="contact" style="display: none;" >
        @csrf
        <div>
            <h3>fff</h3>
            <section>
                <p><strong>Hey! Are you looking for help in planning your trip?</strong></p>
                <p><input type="radio" name="help_planning" id="step_1" value="Yes! A romantic trip" class="required">
                    <span>Yes! A romantic trip</span></p>
                <p><input type="radio" name="help_planning" value="Yes! For a family trip" class="step_1  required">
                    <span>Yes! For a family trip</span></p>
                <p><input type="radio" name="help_planning" value="Yes! A honeymoon trip" class="step_1  required">
                    <span>Yes! A honeymoon trip</span>
                </p>
                <p><input type="radio" name="help_planning" value="Yes! For a trip with my friends"
                          class="step_1 required ">
                    <span>Yes! For a trip with my friends</span>
                </p>
                <p><input type="radio" name="help_planning" value="For a group trip" class="step_1  required">
                    <span>For a group trip</span></p>
                <p><input type="radio" name="help_planning" value="For a solo trip" class="step_1  required">
                    <span>For a solo trip</span></p>
            </section>
            <h3>eee</h3>
            <section>
                <p><strong>May I know what kind of destination you are looking for?</strong></p>
                <p><input type="radio" name="looking_for" value="Adventure" class="required"> <span>Adventure</span></p>
                <p><input type="radio" name="looking_for" value="Leisure" class="required"> <span>Leisure</span></p>
                <p><input type="radio" name="looking_for" value="Beaches" class="required"> <span>Beaches</span></p>
                <p><input type="radio" name="looking_for" value="Hill Stations" class="required">
                    <span>Hill Stations</span></p>
                <p><input type="radio" name="looking_for" value="Nature" class="required"> <span>Nature</span></p>
                <p><input type="radio" name="looking_for" value="Cold Places" class="required"> <span>Cold Places</span>
                </p>
            </section>
            <h3>ddd</h3>
            <section>
                <p><strong>Based on your requirements, here are some suggested destinations.</strong></p>
                <p>You may select from below</p>
                <p><input type="radio" name="suggested_destination" value="Himachal" class="required">
                    <span>Himachal</span></p>
                <p><input type="radio" name="suggested_destination" value="Andaman" class="required">
                    <span>Andaman</span></p>
                <p><input type="radio" name="suggested_destination" value="Uttarakhand" class="required"> <span>Uttarakhand</span>
                </p>
                <p><input type="radio" name="suggested_destination" value="Europe" class="required"> <span>Europe</span>
                </p>
                <p><input type="radio" name="suggested_destination" value="Thailand" class="required">
                    <span>Thailand</span></p>
                <p><input type="radio" name="suggested_destination" value="Others" class="required"> <span>Others</span>
                </p>
            </section>
            <h3>aa</h3>
            <section>
                <p><strong>Is your travel date fixed?</strong></p>
                <p><input type="radio" name="fixed_travel_date" value="Yes" class="required"> <span>Yes</span></p>
                <p><input type="radio" name="fixed_travel_date" value="Not Yet" class="required"> <span>Not Yet</span>
                </p>
            </section>
            <h3>ccc</h3>
            <section>
                <p><strong>Is your travel date fixed?</strong></p>
                <input type="text" placeholder="Firstname" name="firstname" class="required"/>
                <input type="text" placeholder="Surname" name="surname" class="required"/>
                <input type="text" placeholder="Birthdate" name="birthdate" class="required"/>
                <input type="text" placeholder="Insurance number" name="insurance_number" class="required"/>
                <input type="text" placeholder="Family status" name="family_status" class="required"/>
                <select name="month" class="required">
                    <option value="Apr">Apr</option>
                    <option value="May">May</option>
                    <option value="Jun">Jun</option>
                    <option value="Jul">Jul</option>
                    <option value="Aug">Aug</option>
                    <option value="Sep">Sep</option>
                </select>
            </section>
            <h3>bb</h3>
            <section>
                <p><strong>Address</strong></p>
                <input type="text" placeholder="Street, nbr" name="street" class="required"/>
                <input type="text" placeholder="City" name="city" class="required"/>
                <input type="text" placeholder="Postcode" name="post_code" class="required"/>
                <input type="text" placeholder="Country" name="country" class="required"/>
            </section>
            <h3>aaa</h3>
            <section>
                <p><strong>Contact Information</strong></p>
                <input type="text" placeholder="Email address" name="email"/>
                <div><input type="text" name="phone_code" class="phone_code" placeholder="+91"> <input type="text"
                                                                                                       placeholder="Phone"
                                                                                                       name="mobile"
                                                                                                       class="phone_num required"/>
                </div>
                <input type="text" placeholder="Mobile" class="required" name="phone_num"/>
            </section>
        </div>
        {{--        <div class="actions clearfix"><ul role="menu" aria-label="Pagination"><li class="disabled" aria-disabled="true"><a href="#previous" role="menuitem">Previous</a></li><li aria-hidden="false" aria-disabled="false" class="" style="display: list-item;"><a href="#next" role="menuitem">Next</a></li><li aria-hidden="true" style="display: none;"><a href="#finish" role="menuitem">Finish</a></li></ul></div>--}}
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
        crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
<script src="https://kit.fontawesome.com/b66d718ce1.js" crossorigin="anonymous"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@4.0.7/dist/fancybox.umd.min.js"></script>

<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.15.0/jquery.validate.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.js"></script>
<script src="{{ asset('travel/js/custom.js') }}"></script>
</body>
</html>

<div id="myModal" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal">&times;</button>

            <!-- <iframe width="718" height="404" src="https://www.youtube.com/embed/2G6hYuXIaR8?autoplay=1" frameborder="0" allowfullscreen=""></iframe> -->
        </div>

    </div>
</div>
<script type="text/javascript">
    jQuery('.select_travel_month_below a').click(function () {

        jQuery(this).addClass('hli').find('input').prop('checked', true)
    });
    jQuery(document).ready(function () {
        jQuery(".int_destinations").click(function () {
            jQuery(".aaaaaaaa").hide();
            jQuery(".destinations_within_uae").hide();
            jQuery(".internationa_destinations").show();
            jQuery(this).addClass('hlii').find('input').prop('checked', true)
        });
        jQuery(".dest_within_uae").click(function () {
            jQuery(".aaaaaaaa").hide();
            jQuery(".internationa_destinations").hide();
            jQuery(".destinations_within_uae").show();
            jQuery(this).addClass('hlii').find('input').prop('checked', true)
        });

        jQuery(".has-sub > a").append('<i class="fa fa-chevron-down"></i>');
        jQuery(".sec_excerpt .submit").append('<i class="fa fa-chevron-right"></i>');
    });
    var coll = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function () {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
                content.style.display = "none";
            } else {
                content.style.display = "block";
            }
        });
    }
    jQuery("document").ready(function () {
        jQuery(".collapsible").trigger('click');
    });
</script>


<script>
    jQuery(document).ready(function () {
        jQuery("#close").hide();


        jQuery("#contact").hide().delay(5000).queue(function (n) {
            jQuery(this).show();
            n();
            jQuery("#close").show();
        });


        jQuery("#close").click(function () {
            jQuery("#contact").hide();
            jQuery("#close").hide();
        });


    });
</script>
{{-- Previous Work--}}
<script>
    $(document).ready(function () {

        toastr.options.closeButton = true;
        toastr.options.progressBar = true;
        $('.submitt').on('click', function (event) {
            event.preventDefault();
            if (!$('#email').val().length) {
                toastr.error('Email Must Required');
            } else if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test($('#email').val())) {
                var data = {
                    'email': $('#email').val(),
                };
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "{{ url('sendEmail') }}",
                    type: "POST",
                    data: data,
                    // dataType: "json",
                    success: function (data) {
                        console.log(data)
                        if (data === "true") {
                            mailForm.reset();
                            toastr.success('Thanks for subscribing')
                        } else {
                            toastr.error('email already exists')
                        }
                    }
                });
            } else {
                toastr.error('Please Enter a Valid Email');
            }
        });

        $(".owl-carousel").owlCarousel({
            loop: false,
            margin: 10,
            dots: false,
            nav: true,
            items: 3
        });
        var owl = $(".owl-carousel");
        owl.owlCarousel();
        $(".next-btn").click(function () {
            owl.trigger("next.owl.carousel");
        });
        $(".prev-btn").click(function () {
            owl.trigger("prev.owl.carousel");
        });
        $(".prev-btn").addClass("disabled");
        $(owl).on("translated.owl.carousel", function (event) {
            if ($(".owl-prev").hasClass("disabled")) {
                $(".prev-btn").addClass("disabled");
            } else {
                $(".prev-btn").removeClass("disabled");
            }
            if ($(".owl-next").hasClass("disabled")) {
                $(".next-btn").addClass("disabled");
            } else {
                $(".next-btn").removeClass("disabled");
            }
        });

    });
</script>
<script src="{{ asset('frontend/js/style.js') }}"></script>
<script>
    $('#stars li').on('mouseover', function () {
        var onStar = parseInt($(this).data('value'), 10); // The star currently mouse on

        // Now highlight all the stars that's not after the current hovered star
        $(this).parent().children('li.star').each(function (e) {
            if (e < onStar) {
                $(this).addClass('hover');
            } else {
                $(this).removeClass('hover');
            }
        });

    }).on('mouseout', function () {
        $(this).parent().children('li.star').each(function (e) {
            $(this).removeClass('hover');
        });
    });


    /* 2. Action to perform on click */
    $('#stars li').on('click', function () {
        var onStar = parseInt($(this).data('value'), 10); // The star currently selected
        console.log(onStar)
        var stars = $(this).parent().children('li.star');
        console.log(stars)

        for (i = 0; i < stars.length; i++) {
            $(stars[i]).removeClass('selected');
        }

        for (i = 0; i < onStar; i++) {
            $(stars[i]).addClass('selected');
        }

        // JUST RESPONSE (Not needed)
        var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
        $('.rating').val(ratingValue);
        // var msg = "";
        // if (ratingValue > 1) {
        //     msg = "Thanks! You rated this " + ratingValue + " stars.";
        // }
        // else {
        //     msg = "We will improve ourselves. You rated this " + ratingValue + " stars.";
        // }
        // responseMessage(msg);
    });
</script>
