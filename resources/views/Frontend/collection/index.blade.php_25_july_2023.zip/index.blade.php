@extends('Frontend.layouts.master')
@section('content')

<style>
    .checkbox-row label {
        font-weight: normal;
    }

    .d-none {
        display: none;
    }

    .how-it-img {
        margin-top: 10px;
    }

    .popup {
        display: none;
        /* Hide the modal by default */
        position: fixed;
        /* Position it on top of the content */
        z-index: 1;
        /* Make sure it's on top */
        left: 0;
        top: 0;
        width: 100%;
        /* Make it full width */
        height: 100%;
        /* Make it full height */
        overflow: auto;
        overflow-x: hidden;
        /* Enable scrolling if needed */
        background-color: rgba(0, 0, 0, 0.4);
        /* Add a semi-transparent background */
        align-items: center;
        justify-content: center;
        position: absolute;
        position: fixed;
        z-index: 99999;
    }

    .popup-content {
        background-color: #fefefe;
        /* margin: 15% auto; */
        /* Center the modal vertically and horizontally */
        /* padding: 20px; */
        border: 1px solid #888;
        min-width: 760px;
        width: 760px;
        display: flex;
        height: 95vh;
        overflow-y: auto;
        /* margin-top: 10%; */
    }

    .quotesclose-div {
        width: 790px;
        height: 50px;
        position: absolute;
        /* background: black; */
        display: flex;
        justify-content: end;

    }

    .quotesclose-div img {
        width: 30px !important;
    }

    .quotesclose:hover,
    .quotesclose:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

    .location_heading {
        font-family: Lato, sans-serif !important;
        color: #009688;
        display: flex;
        justify-content: center;
        font-weight: 700 !important;
        /* font-size: 31px; */
        margin: 0px;


    }


    .svg {
        width: 50px;
        height: 50px;
    }

    .popup-clearfix {
        background-color: #f2f2f2;
        height: auto;
        width: 41%;
        padding-inline: 10px !important;
        padding-block: 20px;
    }

    .round-bullets {
        border: 1px solid #20a397;
        top: -3px;
    }

    .textes ul li {
        /* line-height: 29px; */
        font-family: Lato, sans-serif !important;
        margin-inline: 10px;
        margin-block: 15px;
        list-style: none;
        /* font-weight: 600; */
        display: flex;
    }

    .round-bullets {
        color: #009688;
        border: 2px solid #20a397;
        /* top: -3px !important; */
        /* border-radius: 67px !important; */
        /* padding: 6px 10px; */
        height: 30px;
        width: 30px;
        border-radius: 100% !important;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .textes ul {
        padding: 0;
    }

    .textes ul li p {
        width: 90%;
        margin: 0;
        padding-left: 10px;
    }

    .card-text {
        font-family: Lato, sans-serif !important;
    }

    .number {

        font-family: Lato, sans-serif !important;
        display: flex;
        font-size: 24px;
        padding-top: 12px;
        padding-bottom: 24px;
        text-align: center;
    }

    .bb {
        border-bottom: 1px solid #d4d4d4;
    }

    .box3 {
        text-align: center;
        display: flex;
        justify-content: space-between;
    }


    h4.card-text {
        margin: 0px;
    }

    .call-detail {
        margin-top: 45px;
        justify-content: center;
        display: flex;
        margin-left: 5px !important;
    }

    span.call-us {
        margin-left: 19px;
    }

    .form-popup {
        width: 59%;
    }

    .yesnobtn {
        justify-content: space-between;
    }

    .yesnobtn>div label {
        background: transparent;
        border: none;
        padding: 12px;
        color: #009688;
    }

    .yesnobtn p b {
        padding: 10px;
    }

    .yesnobtn-2 {
        justify-content: space-between;
    }

    .yesnobtn-2>div label {
        background: transparent;
        border: none;
        padding: 12px;
        color: #009688;
    }

    .yesnobtn-2 p b {
        padding: 10px;
    }


    /* p {
            justify-content: center;
            display: flex;
        } */
</style>
<style>
    .readmore-btn {
        float: right;
    }

    .w-100 {
        width: 100%;
    }

    .border {
        border: 1px solid #d4d4d4;
    }

    .p64 {
        padding: 64px !important;
    }

    .text-center {
        text-align: center;
    }

    .css-17i6t2c {
        width: 300px;
        display: inline-block;
        height: 316px;
        position: relative;
    }

    .css-17i6t2c svg {
        width: 300px;
        height: 316px;
    }

    .css-idm3bz {
        font-size: 32px;
    }

    .mt15 {
        margin-top: 15px !important;
    }

    .pfc3 {
        color: #3e3e3e !important;
    }

    .fwb {
        font-weight: 700;
    }

    .f32 {
        font-size: 32px;
        line-height: 40px;
    }

    .mb15 {
        margin-bottom: 15px !important;
    }

    .wfull {
        width: 100% !important;
    }

    .filter-city-destination>div {
        display: flex;
        gap: 4px;
    }

    .block {
        display: block !important;
    }

    .css-5rbfaa {
        padding: 12px 40px;
        width: 80%;
        max-width: 500px;
    }

    .ripple {
        position: relative;
    }

    .first-letter-caps:first-letter,
    .text-capitalize {
        text-transform: capitalize;
    }

    .btn-filled-pri-large {
        padding-top: 16px;
        padding-bottom: 16px;
        height: 48px;
    }

    .btn-filled-pri,
    .btn-filled-pri-large {
        padding: 12px 25px;
        background-color: #fe5246;
        border: 0;
        color: #fff;
    }

    .btn-filled-pri,
    .btn-filled-pri-large,
    .btn-pri,
    .btn-pri-large,
    .btn-teritary {
        font-size: 14px;
        line-height: 16px;
    }

    .btn-filled-pri,
    .btn-filled-pri-large,
    .btn-filled-sec,
    .btn-filled-sec-large,
    .btn-pri,
    .btn-pri-large,
    .btn-sec,
    .btn-sec-large,
    .btn-teritary {
        display: inline-block;
        text-decoration: none;
        text-transform: capitalize;
        cursor: pointer;
        font-weight: 700;
        -webkit-appearance: none;
    }

    .btn-filled-pri,
    .btn-filled-pri-large,
    .btn-filled-sec,
    .btn-filled-sec-large,
    .btn-pri,
    .btn-pri-large,
    .btn-sec,
    .btn-sec-large,
    .btn-teritary,
    .input,
    .input-with-icon-box input,
    .note,
    .note-green,
    .radius2,
    .select,
    .textarea {
        -webkit-border-radius: 2px;
        -moz-border-radius: 2px;
        -ms-border-radius: 2px;
        border-radius: 2px;
    }

    .pfc1 {
        color: #20a397 !important;
    }

    .agent__trip-id,
    .fw7 {
        font-weight: 700;
    }

    .f16 {
        font-size: 16px;
        line-height: 20px;
    }

    .image-rounded {
        width: 75px;
        height: 68px;
        display: block;
        background-size: 100px 100px;
        border-radius: 50px;
    }

    .txt-mute {
        color: gray !important;
    }

    .read-more-target-2 {
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        /* Adjust the height to control the number of visible lines */
        /* line-height: 1.25em; Adjust the line height for proper spacing */
    }

    .show-content-2 {
        -webkit-line-clamp: unset;
    }

    /*.preloader {*/
    /*    display: none;*/
    /*}*/

    /*.preloader>div {*/
    /*    height: 100vh;*/
    /*    width: 100%;*/
    /*    top: 0;*/
    /*    background: #5f5f5fde;*/
    /*    z-index: 99999;*/
    /*    position: fixed;*/
    /*    display: flex;*/
    /*    justify-content: center;*/
    /*    align-items: center;*/
    /*    color: white;*/
    /*    font-size: 21px;*/
    /*}*/

    .preloader>div {
        height: 100%;
        width: 100%;
        top: 0;
        background: #ffffffd1;
        z-index: 99999;
        position: absolute;
        display: flex;
        justify-content: center;
        align-items: center;
        color: orange;
        font-size: 21px;
    }

    .paginatebtn {
        cursor: pointer;
    }

    .select_dest {
        background-color: #fff;
        float: left;
        width: 33.33%;
        height: 48px;
    }

    .select_dest input {
        background: #fff;
        height: 46px ;
    }

    .z-9 {
        z-index: 9;
    }

    .select_dest input:focus-visible {
        border: none;
    }

    .suggestionbar {
        background: white;
        padding-inline:5px ;
        list-style: none;
        text-align: left;
    }

    .suggestionbar li {
        padding: 5px;
    }
</style>

<div class="inner_banner" style="background: url({{asset('travel/images/kashmir-tour-packages-s.jpg')}}) no-repeat;">
    <h2>{{$single->title ?? 'Tour Packages'}}</h2>
    <div class="sec main_sec section text-center">
        <div class="container">
            <div class="row z-9">
                <form method="GET" id="exp" action="{{url(app()->getLocale().'/tour-package', ['selectedValue' => Request::segment(2) ?? 'default']) }}">
                    @csrf
                    <div class="select_dest">
                        <input class="input-field search-location" required type="text" name="slug" placeholder="{{$translate =App\Helpers\Menus::Translator(48)}}">
                        <div class="" style="position:relative;">
                            <ul class="suggestionbar"></ul>
                        </div>
                    </div>
                    <!-- <select name="slug" id="option" class="select_dest" required>
                        <option selected disabled value="">{{$translate =App\Helpers\Menus::Translator(48)}}</option>
                        @if(isset($citys))
                        @foreach($citys as $city)
                        <option {{isset($single->title) && $single->title==$city->title ? 'Selected' : ''}} value="{{$city->slug}}">{{$city->title ?? ''}}</option>
                        @endforeach
                        @endif
                    </select> -->

                    <select class="select_month" name='month'>
                        <option selected disabled>{{$translate =App\Helpers\Menus::Translator(49)}}</option>
{{--                        @if(isset($months))--}}
{{--                        @foreach($months as $month)--}}
{{--                        @if(isset($month))--}}
{{--                        <option value="{{$month->season_package}}">{{$month->season_package}}--}}
{{--                            , {{ now()->year }}--}}
{{--                        </option>--}}
{{--                        @endif--}}
{{--                        @endforeach--}}
{{--                        @endif--}}
                        <option value="Mar">Mar
                            , {{now()->year}}
                        </option>
                        <option value="Apr">Apr
                            , {{now()->year}}
                        </option>
                        <option value="Jul">Jul
                            , 2023
                        </option>
                        <option value="Dec">Dec
                            , 2023
                        </option>
                        <option value="Feb">Feb
                            , 2023
                        </option>
                        <option value="Jun">Jun
                            , 2023
                        </option>
                        <option value="Sep">Sep
                            , 2023
                        </option>
                        <option value="Nov">Nov
                            , 2023
                        </option>
                        <option value="May">May
                            , 2023
                        </option>
                        <option value="Aug">Aug
                            , 2023
                        </option>
                        <option value="Jan">Jan
                            , 2023
                        </option>
                        <option value="null">Not decided</option>
                    </select>
                    <input type="hidden" name="search_form" id="search_form" value="search_form">
                    <div class="explore_btn_submit"><input type="submit" name="submit" value="{{$translate =App\Helpers\Menus::Translator(58)}}"></div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        const select = document.querySelector('.select_dest#option');
        const form = document.querySelector('#exp');
        const month = document.querySelector('.select_month');
        select.addEventListener('change', function() {
            const selectedValue = select.value;
            exp.action = selectedValue;
        });
    });
</script>
<div class="pkg_city_breif container">
    <div class="bread_crumb">
        <a href="#">Home > </a>
        <a href="#">Tour Packages ></a>
        {{$single->title ?? ''}}
    </div>
    @if(isset($single->title))
    <h2>{{$single->title ?? ''}} </h2>
    @else
    <h2>Tour Packages </h2>
    @endif
    <div class="">
        <div class="contentboxtoggle ">
            @if(isset($single->description))


            <div class="read-more-target-2">{!! $single->description ?? '' !!}</div>


            @else
            <p class="read-more-target-2">Tour Packages are one of the best ways to travel hassle-free. With
                seamless planning, arrangements, and
                transfers being taken care of, booking tour packages from india is the best way to explore the
                world’s
                varied landscapes. We all have our reasons and excuses to travel. Either we’re looking for a
                solo
                adventure, seeking a quiet romantic getaway with our partner, or taking the whole family for a
                memorable
                holiday vacation. Whatever the reason is, our packages make sure every tourist gets an
                experience to
                cherish for a long time.
                20 Best Destinations For Tour Packages From India In 2023
                Tour packages offered by Dopamine Travel cover prime destinations such as Maldives, Thailand,
                Kerala,
                Goa, Bali, Andaman, Dubai, Sri Lanka, Himachal, Rajasthan, Europe, and much more. These packages
                take
                you from lush valleys, snow-capped mountains and pristine beaches to well-preserved wildlife
                sanctuaries, adventure spots, ancient monuments, and historical and cultural hubs - there is a
                lot to
                explore and experience. With an array of exotic tourist destinations, including the ones
                mentioned
                below, our travelers are spoilt for choice.</p>

            @endif
            <a href="#" class="readmore-btn" id="readMoreButton">{{$translate =App\Helpers\Menus::Translator(111)}} <i class="fa fa-chevron-down"></i></a>
        </div>
    </div>
    <h2>{{$single->title ?? ''}} </h2>
    <div class="cities_tags">
        @if(isset($cityss))
        @foreach($cityss as $city)
        <a href="#">{{$city->title ?? ''}}</a>
        @endforeach
        @endif
    </div>
</div>
<section class="sec section perfect_holiday category">

    <div class="container simple_filters">


        <div class="total_packges_with_slider">


            <div class="slider_red_price_0 row">


                <div class="col-sm-3">

                    <button type="button" class="active collapsible">{{$translate =App\Helpers\Menus::Translator(136)}} <i class="fa fa-chevron-down"></i>
                    </button>
                    <div class="content">
                        @if(isset($categories))
                        @foreach ($categories as $key => $category)
                        <div class="row row- destination-type-body d-flex">
                            <?php
                            if (isset($_GET['categories'])) {
                                $myArray = explode(',', $_GET['categories']);
                            } elseif ($slug != null) {
                                $myArray = array($slug);
                            } else {
                                $myArray = [];
                            }
                            ?>
                            <input name="category_filter[]" {{ in_array($category->slug, $myArray) ? 'checked' : '' }} id="category_id{{$key}}" type="checkbox" class="checkbox-common at_category_honeymoon submit-form" value="{{ $category->slug }}">
                            <label for="category_id{{$key}}">{{ $category->title ?? '' }}</label>
                        </div>
                        @endforeach
                        @endif
                    </div>

                    <p class="paddtop">{{$translate =App\Helpers\Menus::Translator(138)}} <a class="reset-link" href="">RESET</a></p>
                    <hr>
                    <button type="button" class="active collapsible">{{$translate =App\Helpers\Menus::Translator(137)}} <i class="fa fa-chevron-down"></i></button>
                    <div class="content">
                        <div class="row row- destination-type-body">
                            <?php
                            if (isset($_GET['duration'])) {
                                $durationArray = explode(',', $_GET['duration']);
                            } else {
                                $durationArray = [];
                            }
                            ?>
                            <div><input name="duration_filter[]" id="duration1" {{ in_array('1-3', $durationArray) ? 'checked' : '' }} type="checkbox" class="checkbox-common at_duration_13 submit-form" value="1-3">
                                <label for="duration1">1 to 3 <span class="hide">[19]</span>
                                </label>
                            </div>
                            <div><input name="duration_filter[]" id="duration2" {{ in_array('4-6', $durationArray) ? 'checked' : '' }} type="checkbox" class="checkbox-common at_duration_46 submit-form" value="4-6">
                                <label for="duration2">4 to 6 <span class="hide">[103]</span>
                                </label>
                            </div>
                            <div><input name="duration_filter[]" id="duration3" {{ in_array('7-9', $durationArray) ? 'checked' : '' }} type="checkbox" class="checkbox-common at_duration_79 submit-form" value="7-9">
                                <label for="duration3">7 to 9 <span class="hide">[61]</span>
                                </label>
                            </div>
                            <div><input name="duration_filter[]" id="duration4" {{ in_array('10-12', $durationArray) ? 'checked' : '' }} type="checkbox" class="checkbox-common at_duration_1012 submit-form" value="10-12">
                                <label for="duration4">10 to 12 <span class="hide">[14]</span>
                                </label>
                            </div>
                            <div><input name="duration_filter[]" id="duration5" {{ in_array('13-100', $durationArray) ? 'checked' : '' }} type="checkbox" disabled="" class="checkbox-common at_duration_L13 submit-form" value="13-100">
                                <label for="duration5">13 or more <span class="hide">[0]</span>
                                </label>
                            </div>
                        </div>
                        <p><a class="reset-link" href="">Clear</a></p>
                    </div>
                    <button type="button" class="active collapsible">{{$translate =App\Helpers\Menus::Translator(139)}} ( in Rs. ) <i class="fa fa-chevron-down"></i></button>
                    <div class="content">
                        <?php
                        if (isset($_GET['price_range'])) {
                            $budgetArray = explode(',', $_GET['price_range']);
                        } else {
                            $budgetArray = [];
                        }
                        ?>
                        <div class="row row- destination-type-body">
                            <div><input name="budget_filter[]" id="budget_id1" {{ in_array('0-1000', $budgetArray) ? 'checked' : '' }} value="0-1000" type="radio" class="checkbox-common at_budget1 submit-form">
                                <label for="budget_id1">Less Than 1000 <span class="hide">[9]</span>
                                </label>
                            </div>
                            <div><input name="budget_filter[]" id="budget_id2" {{ in_array('1000-2000', $budgetArray) ? 'checked' : '' }} value="1000-2000" type="radio" class="checkbox-common at_budget2 submit-form">
                                <label for="budget_id2">1000 - 2000 <span class="hide">[93]</span>
                                </label>
                            </div>
                            <div><input name="budget_filter[]" id="budget_id3" {{ in_array('2000-4000', $budgetArray) ? 'checked' : '' }} value="2000-4000" type="radio" class="checkbox-common at_budget2 submit-form">
                                <label for="budget_id3">2000 - 4000 <span class="hide">[93]</span>
                                </label>
                            </div>
                            <div><input name="budget_filter[]" id="budget_id4" {{ in_array('4000-6000', $budgetArray) ? 'checked' : '' }} value="4000-6000" type="radio" class="checkbox-common at_budget2 submit-form">
                                <label for="budget_id4">4000 - 6000 <span class="hide">[93]</span>
                                </label>
                            </div>
                            <div><input name="budget_filter[]" id="budget_id5" {{ in_array('6000-8000', $budgetArray) ? 'checked' : '' }} value="6000-8000" type="radio" class="checkbox-common at_budget2 submit-form">
                                <label for="budget_id5">6000 - 8000 <span class="hide">[93]</span>
                                </label>
                            </div>
                            <div><input name="budget_filter[]" id="budget_id6" {{ in_array('8000-100000000', $budgetArray) ? 'checked' : '' }} value="8000-100000000" type="radio" class="checkbox-common at_budget6 submit-form">
                                <label for="budget_id6">Above 8000 <span class="hide">[1]</span>
                                </label>
                            </div>
                        </div>

                        <p><a class="reset-link" href="">Clear</a></p>
                    </div>
                    <button type="button" class="active collapsible">{{$translate =App\Helpers\Menus::Translator(140)}} <i class="fa fa-chevron-down"></i></button>
                    <div class="content">
                        <div class="row">
                            <?php
                            if (isset($_GET['rating'])) {
                                $ratingArray = explode(',', $_GET['rating']);
                            } else {
                                $ratingArray = [];
                            }
                            ?>
                            <div class="star_rating_filters"><input name="rating_filter[]" id="rating_id1" type="checkbox" class="checkbox-common at_hotelrating5 submit-form" {{ in_array('5', $ratingArray) ? 'checked' : '' }} value="5">
                                <label for="rating_id1">
                                    <span><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i> 5 Stars</span>
                                </label>

                            </div>

                            <div class="star_rating_filters"><input name="rating_filter[]" id="rating_id2" {{ in_array('4', $ratingArray) ? 'checked' : '' }} type="checkbox" class="checkbox-common at_hotelrating4 submit-form" value="4">
                                <label for="rating_id2">
                                    <span><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i> 4 Stars</span>
                                </label>
                            </div>

                            <div class="star_rating_filters"><input name="rating_filter[]" id="rating_id3" type="checkbox" class="checkbox-common at_hotelrating3 submit-form" {{ in_array('3', $ratingArray) ? 'checked' : '' }} value="3">
                                <label for="rating_id3">
                                    <span><i class="five-pointed-star"></i><i class="five-pointed-star"></i><i class="five-pointed-star"></i> 3 Stars</span>
                                </label>
                            </div>

                            <div class="star_rating_filters"><input name="rating_filter[]" id="rating_id4" type="checkbox" class="checkbox-common at_hotelrating2 submit-form" {{ in_array('2', $ratingArray) ? 'checked' : '' }} value="2">
                                <label for="rating_id4">
                                    <span><i class="five-pointed-star"></i><i class="five-pointed-star"></i> 2 Stars</span>
                                </label>
                            </div>
                            <div class="star_rating_filters"><input name="rating_filter[]" id="rating_id5" type="checkbox" class="checkbox-common at_hotelrating1 submit-form" {{ in_array('1', $ratingArray) ? 'checked' : '' }} value="1">
                                <label for="rating_id5">
                                    <span><i class="five-pointed-star"></i> 1 Star</span>

                                </label>
                            </div>
                            <p><a class="reset-link" href="">Clear</a></p>
                        </div>
                    </div>

                    <button type="button" class="active collapsible">Activities <i class="fa fa-chevron-down"></i>
                    </button>
                    <div class="content">
                        <div class="row">
                            @if(isset($activities))
                            @foreach ($activities as $key => $activitie)
                            <?php
                            if (isset($_GET['activities'])) {
                                $activitieArray = explode(',', $_GET['activities']);
                            } else {
                                $activitieArray = [];
                            }
                            ?>

                            <div><input name="activity_filter[]" id="activity_id{{$key}}" type="checkbox" {{ in_array($activitie->slug, $activitieArray) ? 'checked' : '' }} class="checkbox-common at_activity1 submit-form" value="{{ $activitie->slug }}">
                                <label for="activity_id{{$key}}">{{ $activitie->title ?? ''}}</label>
                            </div>
                            @endforeach
                            @endif
                        </div>
                    </div>

                    <?php
                    if (isset($_GET['cities']) && $_GET['cities'] != null) {
                        $citiesArray = explode(',', $_GET['cities']);
                    }

                    elseif (isset($city_id) && $city_id != null) {
                        $citiesArray = array($city_id);
                    } else {
                        $citiesArray = [];
                    }
                    ?>


{{--                    @dd($citiesArray)--}}
                    <button type="button" class="active collapsible">Cities <i class="fa fa-chevron-down"></i>
                    </button>
                    <div class="content">
                        <div class="filter-city-destination">
                            @if(isset($cities))
                            @foreach ($cities as $key => $city)
                            <div class="row row- destination-type-body">
                                <input name="cities_filter[]" id="cities_id{{$key}}" type="checkbox" class="checkbox-common submit-form" {{ in_array($city->id, $citiesArray) ? 'checked' : '' }} value="{{ $city->id ?? ''}}">
                                <label class="block pl30 _238cf_g" for="cities_id{{$key}}">{{ $city->title ?? ''}}
                                    <span class="hide">[82]</span>
                                </label>
                            </div>
                            @endforeach
                            @endif
                        </div>
                        <p><a class="reset-link" href="">Clear</a></p>
                    </div>

                    <button type="button" class="active collapsible">Inclusions <i class="fa fa-chevron-down"></i>
                    </button>
                    <div class="content">
                        <div class="row">
                            @if(isset($inclusions))
                            @foreach ($inclusions as $key => $inclusion)
                            <?php
                            if (isset($_GET['inclusion'])) {
                                $inclusionArray = explode(',', $_GET['inclusion']);
                            } else {
                                $inclusionArray = [];
                            }
                            ?>

                            <div><input name="inclusion_filter[]" id="inclusion_id{{$key}}" type="checkbox" {{ in_array($inclusion->id, $inclusionArray) ? 'checked' : '' }} class="checkbox-common at_inclusion0 submit-form" value="{{ $inclusion->id }}"><label for="inclusion_id{{$key}}">{{ $inclusion->title }}</label>
                            </div>
                            @endforeach
                            @endif
                            <p><a class="reset-link" href="">Clear</a></p>
                        </div>
                    </div>
                </div>


                <div class="col-sm-9  position-relative">
                    <div class="preloader">
                        <div>
                            Loading....
                        </div>
                    </div>
<div class="product-append">
{{--    @include('Frontend/snippets/package-view')--}}
</div>


                    <!-- cate2 -->

                    {{-- @if(count($package) == 0)--}}
                    {{-- --}}
                    {{-- @else--}}



                    {{-- @endif--}}
                </div>





            </div>
        </div>
    </div>
</section>
<section class="tranding_holidays">
    <div class="container">
        <h4><span class="trending">TRENDING</span> Holiday Destinations</h4>
        <div class="row row_destinations_packages slider_destinations">
            @if(isset($holidays))
            @foreach ($holidays as $holiday)
            <div class="col-sm-2">
                @if ($holiday->image != null)
                @php $image = $holiday->image @endphp
                @else
                @php $image = 'galleryimage.png' @endphp
                @endif
                <div><img style="" src="{{ asset('images/media' . '/' . $image) }}"><a class="see-details-button absolute-center" href="{{ url(app()->getLocale().'/packages',$holiday->slug) }}">View
                        Packages</a></div>
                <h3>{{ $holiday->title ?? ''}}<span>Starting from</span></h3>
                <p class="price_line">75+ packages
                    <span>{{$currency->currency_symbol}}
                        @if($holiday->discount_price != null)
                        {{$holiday->discount_price * $currency->currency_rate}}
                        @elseif($holiday->compare_price != null)
                        {{$holiday->compare_price * $currency->currency_rate}}
                        @endif
                    </span>
                </p>
            </div>
            @endforeach
            @else
            <div class="col-sm-2">
                <h1>No Holiday Destinations Found</h1>
            </div>
            @endif
        </div>
        <div class="packages_inner d-none">
            <h4>USA Tour Packages by Theme</h4>
            <a href="#">USA Budget Tour Packages </a>
            <a href="#">USA Luxury Tour Packages</a>
            <a href="#">USA Trekking Tour Packages</a>
            <a href="#">USA Group Tour Packages</a>
            <hr>
            <h4>Hotels in USA by Star Ratings</h4>
            <a href="#">5 Star Hotels in USA</a>
            <a href="#">4 Star Hotels in USA</a>
            <a href="#">3 Star Hotels in USA</a>
            <hr>
        </div>
    </div>
</section>
<section class="sec section faq_sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <h4>{{$faqs[0]->title ?? 'FAQs'}}</h4>
                <div class="panel-group" id="accordion">
                    @if(count($faqs)>0)
                    @foreach($faqs as $faq)
                    <div class="panel panel-default">
                        <div class="panel-headingaa">
                            <h4 class="panel-title">
                                <a class="accordion-toggle">
                                    {{ $faq->faqs_question ?? ''}}
                                </a>
                            </h4>
                        </div>
                        <div id="collapse1{{ $loop->index === 0 ? 'active' : ''}}" class="panel-collapse collapse">
                            <div class="panel-body">
                                {{ $faq->faqs_answer ?? ''}}.
                            </div>
                        </div>
                    </div>
                    @endforeach
                    @else
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                                    What does a tour package include?
                                </a>
                            </h4>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse in">
                            <div class="panel-body">
                                A tour package aspires to cover various travel requirements of different
                                travellers. Each tour package comes with its set of features and travellers can
                                choose any package, according to their suitability. From family tour packages to
                                honeymoon tour packages, each package is exclusively curated, keeping in mind
                                the travellers’ needs. A tour package may include some of the following aspects
                                to help you enjoy a perfect holiday.

                                Stay at a luxury hotel, offering an array of modern amenities.
                                Sightseeing of prominent landmarks in the respective tour destinations.
                                Meals may also be included, it depends on the package you opt for.
                                Cab or taxi services may also be provided. Again, this depends on the package
                                you choose.
                                Some packages may also include certain adventure activities and recreational
                                activities.
                                All in all, a tour package intends to smoothen out your travel experience,
                                adding value to your vacation, each package is customized to provide travellers
                                the best vacation experience. Choose a tour package according to your
                                requirements or customized one with our help!
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                                    What type of tour packages are available?
                                </a>
                            </h4>
                        </div>
                        <div id="collapse3" class="panel-collapse collapse">
                            <div class="panel-body">
                                There are various types of tour packages available, each one befitting the
                                varied needs of travellers. To provide you with a wholesome vacation, there are
                                diverse categories of tour packages that can easily be availed. Some of them
                                are: family tour packages, honeymoon tour packages, luxurious tour packages,
                                sightseeing tour packages, adventure tour packages, tour packages for solo
                                travellers, etc. Explore the various packages and opt the most suitable one for
                                you.
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapse4">
                                    What are the top travel destinations in 2023?
                                </a>
                            </h4>
                        </div>
                        <div id="collapse4" class="panel-collapse collapse">
                            <div class="panel-body">
                                While there are so many travel destinations in the world, top 10 travel
                                destinations as per the latest trend of 2023 are :

                                Rome, Europe
                                Grand Canyon in the United States of America
                                Uttarakhand, India
                                France, Europe
                                Canterbury Region, New Zealand
                                Hoang Lien Son, Vietnam
                                Alberta, Canada
                                Oman
                                Vevey, Switzerland
                                Italy, Europe
                                Out of all the travel destinations listed here, you can plan an executable
                                itinerary for a holiday tour or book a tour package during any time of the year.
                            </div>
                        </div>
                    </div>
                    @endif
                </div>
                {{-- <div class="text-center"><a href="#" class="load_more">Load More</a></div>--}}


            </div>
            <div class="col-sm-4">
                <div class="agent_box">
                    <h4>Why Book With Our Agents?</h4>


                    <p><strong>Only The Best Agents</strong>

                        Travelers deal with only the top 10% reviewed agents who are selected after a 23 step
                        rigorous
                        assessment procedure by Dopamine Travel.</p>

                    <hr>

                    <p><strong>Ensuring Quality</strong>

                        Dopamine Travel ensures quality service via verified partners by releasing the payment only
                        after
                        the booking vouchers/receipts are received by the traveler.</p>
                    <hr>

                    <p><strong>24*7 On-trip assistance by Local Travel Agents</strong>

                        Travelers deal with only the top 10% reviewed agents who are selected after a 23 step
                        rigorous
                        assessment procedure by Dopamine Travel.</p>
                </div>


            </div>
        </div>
    </div>
</section>
<section class="sec section incredibly_sec">
    <div class="container">
        <div class="row incredibly_text">
            <div class="col-sm-8">
                <h3>Authentic Traveler Reviews</h3>
                <p>Read on to find out why our customers love us!</p>
            </div>
            <div class="col-sm-4 text-right">
                <a href="#"><a href="#">View All</a></a>
            </div>
        </div>

        <div class="row incredibly_slider text-center">
            @if(isset($reviews))
            @foreach ($reviews as $review)
            <div class="col-sm-4">
                <div class="reviews_inner_wrape">

                    <h4>{{$review->title ?? ''}}</h4>
                    <p>{!! $review->comment ?? '' !!}</p>
                    <div class="row">
                        <div class="col-sm-3">
                            <img src="{{ asset('images/profile/avatar.png') }}" class="image-rounded" alt="">
                        </div>
                        <div class="col-sm-9 nopad">
                            <div class="stars_wrape">

                                @for ($x = 1; $x <= $review->rating; $x++)
                                    <i class="fa fa-star"></i>
                                    @endfor
                                    @for ($x = $review->rating; $x <= 4; $x++) <i class="fa fa-star txt-mute"></i>
                                        @endfor
                                        <span>{{$review->name ?? ''}}</span>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</section>
<section class="sec section incredibly_sec travel_blogs">
    <div class="container">

        <div class="row incredibly_text">
            <div class="col-sm-8">
                <h3>Top Travel Blogs for USA</h3>
                <p>They Traveled. They Experienced. They Shared.</p>
            </div>
            <div class="col-sm-4 text-right">
                <a href="{{url('https://client.edwomtech.com/dopaminetravel_wp/')}}">{{$translate =App\Helpers\Menus::Translator(109)}}</a>
            </div>
        </div>

        <div class="row incredibly_slider text-center">
            @foreach($blogs as $blog)
            <div class="col-sm-4">
                <div class="incredibly_slider_inner">
                    <img src="{{$blog->thumbnail_url}}">
                    <h4>{{$blog->title}}</h4>
                    <p class="pull-right">
                        <a href="#">{{$translate =App\Helpers\Menus::Translator(111)}}</a>
                    </p>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

@if (isset($similarPackage))
<section class="similar_sec_travel">
    <div class="container">
        <h4>Similar Destinations</h4>
        <p>Unlimited Choices. Customised Vacations. Happy Memories</p>
        <div class="row row_destinations_packages similar_sec_travel_slider">
            @foreach ($similarPackage as $pack)
            <div class="col-sm-2">
                <div class="similar_inner">
                    @if ($pack->image != null)
                    @php $image = '/'.$pack->image @endphp
                    @else
                    @php $image = 'galleryimage.png' @endphp
                    @endif
                    <img src="{{ asset('images/media' . '/' . $image) }}">
                    <div class="content_sec">
                        <h3>{{$pack->title ?? ''}}
                            <span style="color: red">{{$currency->currency_symbol}}
                                @if($pack->discount_price != null)
                                {{$pack->discount_price * $currency->currency_rate}}
                                @elseif($pack->compare_price != null)
                                {{$pack->compare_price * $currency->currency_rate}}
                                @endif
                            </span>
                        </h3>

                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
@endif
<!-- <section class="similar_sec_travel visit_to_kashmir">
        <div class="container">
            <h4>Places To Visit In USA</h4>
            <p>Let the experts guide you to the best of this mesmerizing destination</p>
            <div class="row row_destinations_packages similar_sec_travel_slider">
                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/amarnath_yatra.jpg') }}">
                        <div class="content_sec">
                            <h3>Amarnath Yatra In Pahalgam</h3>
                            <p class="price_line">Nestled at a height of about 12,756 feet, the most famous and revered
                                shrine of Amarnath is dedicated to Lord Shiva. Every year, lakhs of devotees embark
                                on </p>
                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class="css-18g8ve5">
                                        <li>Religious trek</li>
                                        <li>Temple</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/amarnath_yatra.jpg') }}">
                        <div class="content_sec">
                            <h3>Amarnath Yatra In Pahalgam</h3>
                            <p class="price_line">Nestled at a height of about 12,756 feet, the most famous and revered
                                shrine of Amarnath is dedicated to Lord Shiva. Every year, lakhs of devotees embark
                                on </p>
                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class="css-18g8ve5">
                                        <li>Religious trek</li>
                                        <li>Temple</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/amarnath_yatra.jpg') }}">
                        <div class="content_sec">
                            <h3>Amarnath Yatra In Pahalgam</h3>
                            <p class="price_line">Nestled at a height of about 12,756 feet, the most famous and revered
                                shrine of Amarnath is dedicated to Lord Shiva. Every year, lakhs of devotees embark
                                on </p>
                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class="css-18g8ve5">
                                        <li>Religious trek</li>
                                        <li>Temple</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/amarnath_yatra.jpg') }}">
                        <div class="content_sec">
                            <h3>Amarnath Yatra In Pahalgam</h3>
                            <p class="price_line">Nestled at a height of about 12,756 feet, the most famous and revered
                                shrine of Amarnath is dedicated to Lord Shiva. Every year, lakhs of devotees embark
                                on </p>
                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class="css-18g8ve5">
                                        <li>Religious trek</li>
                                        <li>Temple</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="similar_sec_travel visit_to_kashmir">
        <div class="container">
            <h4>Things To Do In USA</h4>
            <p>Your list of the best things to do, compiled on the basis of actual traveler experiences</p>
            <div class="row row_destinations_packages similar_sec_travel_slider">


                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/tea-plucking.jpg') }}">
                        <div class="content_sec">
                            <h3>Tea Plucking in Gulmarg</h3>
                            <p class="price_line">When talking about “things to do” in <strong>Gulmarg</strong>, you can
                                indulge in tea plucking. Of course, there`s no skipping the mountainous adventure sports
                                like skiing and snowboarding but you must also get to experience the local
                                non-adventurous
                                activities like tea plucking. </p>
                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class=" css-18g8ve5">
                                        <li>Tea gardens</li>
                                        <li>Sightseeing</li>
                                        <li>Nature</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/tea-plucking.jpg') }}">
                        <div class="content_sec">
                            <h3>Tea Plucking in Gulmarg</h3>
                            <p class="price_line">When talking about “things to do” in <strong>Gulmarg</strong>, you can
                                indulge in tea plucking. Of course, there`s no skipping the mountainous adventure sports
                                like skiing and snowboarding but you must also get to experience the local
                                non-adventurous
                                activities like tea plucking.</p>


                            <div class="row">
                                <div class="col-sm-9">
                                    <ul class=" css-18g8ve5">
                                        <li>Tea gardens</li>
                                        <li>Sightseeing</li>
                                        <li>Nature</li>
                                    </ul>
                                </div>
                                <div class="col-sm-3">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>


                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/tea-plucking.jpg') }}">
                        <div class="content_sec">
                            <h3>Tea Plucking in Gulmarg</h3>
                            <p class="price_line">When talking about “things to do” in <strong>Gulmarg</strong>, you can
                                indulge in tea plucking. Of course, there`s no skipping the mountainous adventure sports
                                like skiing and snowboarding but you must also get to experience the local
                                non-adventurous
                                activities like tea plucking.</p>
                            <div class="row">
                                <div class="col-sm-8">
                                    <ul class=" css-18g8ve5">
                                        <li>Tea gardens</li>
                                        <li>Sightseeing</li>
                                        <li>Nature</li>
                                    </ul>
                                </div>
                                <div class="col-sm-4">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-sm-2">
                    <div class="similar_inner"><img src="{{ asset('travel/images/tea-plucking.jpg') }}">
                        <div class="content_sec">
                            <h3>Tea Plucking in Gulmarg</h3>
                            <p class="price_line">When talking about “things to do” in <strong>Gulmarg</strong>, you can
                                indulge in tea plucking. Of course, there`s no skipping the mountainous adventure sports
                                like skiing and snowboarding but you must also get to experience the local
                                non-adventurous
                                activities like tea plucking.</p>
                            <div class="row">
                                <div class="col-sm-8">
                                    <ul class=" css-18g8ve5">
                                        <li>Tea gardens</li>
                                        <li>Sightseeing</li>
                                        <li>Nature</li>
                                    </ul>
                                </div>
                                <div class="col-sm-4">
                                    <a href="#" class="view_All_btn">Read More</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="sec section who_we_are">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-left">
                    <h3>Personal Experiences Of Our Travelers</h3>
                    <p><strong>1. Rachit Seth:</strong> Our journey from UK to USA</p>
                    <p><strong>Duration:</strong> 4N/5D</p>

                    <p><strong>Accommodation:</strong> Hotel</p>

                    <p><strong>Experience Cherished:</strong> Houseboat and Gondola Ride</p>

                    <p><strong>Come Back For:</strong> To meet our friend Mr. Ahmad, our cab driver</p>
                    <div class="contentboxtoggle">
                        <p class="read-more-target-2">Being from UK, I always wanted to witness the beauty of USA and
                            its
                            mountainous
                            landscape. I
                            came across Dopamine Travel through their online ad and after looking
                            for USA
                            travel
                            packages, I
                            was impressed by their itinerary and quotes. I decided to book a package from them. The
                            mountain
                            view from Pahalgam is something me and my wife would never forget. We also thoroughly
                            enjoyed
                            our
                            stay in a houseboat. We went to Gulmarg for Gondola ride and also enjoyed the Shikara ride
                            at
                            Srinagar which were amazing experiences. The last day we visited Sonamarg and the white
                            sheet of
                            snow there was eye-soothing.</p>

                        <p class="pull-right"><a class="readmore-btn" onclick="toggleContent()" href="#">Read More</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section> -->

<section class="d-none sec section incredibly_sec travel_blogs">
    <div class="container">

        <div class="row incredibly_text">
            <div class="col-sm-8">
                <h4>Things To Do In USA</h4>
                <p>Your list of the best things to do, compiled on the basis of actual traveler experiences</p>
            </div>
            <div class="col-sm-4 text-right">
                <a href="{{url('https://client.edwomtech.com/dopaminetravel_wp/')}}">{{$translate =App\Helpers\Menus::Translator(109)}}</a>
            </div>
        </div>

        <div class="row incredibly_slider text-center">
            @foreach($blogs as $blog)
            <div class="col-sm-4">
                <div class="incredibly_slider_inner">
                    <img src="{{$blog->thumbnail_url}}">
                    <h4>{{$blog->title}}</h4>
                    <p class="pull-right">
                        <a href="#">{{$translate =App\Helpers\Menus::Translator(111)}}</a>
                    </p>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>


<section class="d-none sec section incredibly_sec travel_blogs">
    <div class="container">

        <div class="row incredibly_text">
            <div class="col-sm-8">
                <h4>Places To Visit In USA</h4>
                <p>Let the experts guide you to the best of this mesmerizing destination</p>
            </div>
            <div class="col-sm-4 text-right">
                <a href="{{url('https://client.edwomtech.com/dopaminetravel_wp/')}}">{{$translate =App\Helpers\Menus::Translator(109)}}</a>
            </div>
        </div>

        <div class="row incredibly_slider text-center">
            @foreach($blogs as $blog)
            <div class="col-sm-4">
                <div class="incredibly_slider_inner">
                    <img src="{{$blog->thumbnail_url}}">
                    <h4>{{$blog->title}}</h4>
                    <p class="pull-right">
                        <a href="#">{{$translate =App\Helpers\Menus::Translator(111)}}</a>
                    </p>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>

<div id="quotesmyModal" class="popup">
    <div class="popup-content">
        <div class=" quotesclose-div">

            <img src="{{asset('images/dopamine/sa.svg#CloseWhite-usage')}}  " class=" quotesclose" alt="">
        </div>

        <!-- <span class="quotesclose">&times;</span> -->
        <div class="popup-clearfix">
            <h4 class="location_heading ">How It Works</h4>
            <div class="textes">
                <ul>
                    <li>
                        <span class="round-bullets ">1</span>
                        <p>Tell us details of your holiday plan.</p>
                    </li>
                    <li>
                        <span class="round-bullets">2</span>
                        <p>Get multiple quotes from expert agents, compare &amp; customize further.</p>
                    </li>
                    <li>
                        <span class="round-bullets ">3</span>
                        <p>Select &amp; book best deal.</p>
                    </li>
                </ul>
            </div>
            <div class="box3">
                <div class="card">
                    <img src="{{asset('images/dopamine/sa.svg#IllusAgent-usage')}}  " class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">650+</h4>
                        <p class="para">Verified Agents</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{asset('images/dopamine/na.svg#IllusMoneySafe-usage')}} " class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">Dopamine Travel</h4>
                        <p class="para">Verified</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{asset('images/dopamine/na.svg#IllusQualityCheck-usage')}}" class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">Stringent</h4>
                        <p class="para">Quality Control</p>
                    </div>
                </div>
            </div>
            <hr class="bb">

            <div class="call-detail">
                <span class="icon">
                    <img src="WhatsApp Image 2023-05-13 at 1.45.31 AM (1).jpeg" class="icon" alt="">
                </span>
                <span class="para">Call Us for details</span>
            </div>
            <h3 class="location_heading">
                1800-123-5555</h3>
            <p class="text-center ">650+ Agents | 40 Lac+ Travelers | 65+ Destinations</p>


        </div>
        <div class="form-popup">
            @include('Frontend/snippets/form-package')

        </div>


    </div>

</div>
<input type="hidden" name="search_form" id="search_form" value="{{$search_form ?? ''}}">
<input type="hidden" name="language" id="language" value="{{app()->getLocale()}}">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>

<script>
    $(document).ready(function() {
        // Get the modal
        var popup = document.getElementById("quotesmyModal");

        // Get the button that opens the modal
        // var btn = $('.quotesBtn')
        // var btn = document.getElementsByClassName("quotesBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("quotesclose")[0];

        // When the user clicks on the button, open the modal
        $('body').on('click', '.quotesBtn', function(e) {
            popup.style.display = "flex";
            var btnId = e.target.dataset.id;
            var a = $('#packageid').val(btnId);
            console.log(a);
            reqdiv();



        })
        // When the user clicks on the <span> (x), close the modal
        span.onclick = function() {
            popup.style.display = "none";
            $('#regForm').find('.date-btn').css('display', 'flex')
            $('#regForm').find('.selectedDateContainerp2').css('display', 'none')
            // showTab(0);

            $('#dayheading').css('display', 'none')
            currentTab = 0;
            // Reset the form and its elements
            var form = document.getElementById("regForm");
            $('#packageid').val('');
            form.reset();


            // Reset the step indicators
            var stepIndicators = document.getElementsByClassName("step-2");
            for (var i = 0; i < stepIndicators.length; i++) {
                stepIndicators[i].className = "step-2";
            }
            var tabs = document.getElementsByClassName("tabmain");
            for (var i = 1; i < tabs.length; i++) {
                tabs[i].style.display = "none";
            }

            // Display the first tab
            showTab(currentTab);
        }


        // When the user clicks anywhere outside of the modal, quotesclose it
        window.onclick = function(event) {

            if (event.target == popup) {
                popup.style.display = "none";
                $('#regForm').find('.date-btn').css('display', 'flex')
                $('#regForm').find('.selectedDateContainerp2').css('display', 'none')
                // showTab(0);

                $('#dayheading').css('display', 'none')
                currentTab = 0;
                // Reset the form and its elements
                var form = document.getElementById("regForm");

                form.reset();


                // Reset the step indicators
                var stepIndicators = document.getElementsByClassName("step-2");
                for (var i = 0; i < stepIndicators.length; i++) {
                    stepIndicators[i].className = "step-2";
                }
                var tabs = document.getElementsByClassName("tabmain");
                for (var i = 1; i < tabs.length; i++) {
                    tabs[i].style.display = "none";
                }

                // Display the first tab
                showTab(currentTab);

            }

        }
        // var picker = new Pikaday({
        //     field: document.getElementById('datepicker'),
        //     format: 'YYYY-MM-DD',
        //     position: 'bottom left'
        // });

        // const select = document.querySelector('#option');
        // const form = document.querySelector('form');
        // const month = document.querySelector('.select_month');
        //
        // select.addEventListener('change', function () {
        //     const selectedValue = select.value;
        //     // const action = form.action.replace('default', selectedValue);
        //     // form.action = action;
        //     console.log('aaaaaaaaa')
        //     form.action = `tour-package/${selectedValue}`;
        // });
        //
        // month.addEventListener('change', function () {
        //     console.log('aaaaaaaaa')
        //
        //     form.action = `${form.action}?month=${month.value}`;
        // });

        // jQuery('accordion-toggle').click(function() {
        //     jQuery(this).toggleClass('accordion-btn--open');
        //     jQuery(this).toggleClass('button--arrow-right');
        // });
        $('.panel-headingaa').on('click', function() {
            $(this).siblings('div').slideToggle().toggleClass('in')
        })


        $('.readmore-btn').on('click', function() {
            $(this).parents('.contentboxtoggle').find('.read-more-target-2').toggleClass('show-content-2');
            var button = document.getElementById("readMoreButton");
            if (document.querySelector(".read-more-target-2").classList.contains("show-content-2")) {
                button.innerHTML = "Read Less";
            } else {
                button.innerHTML = "{{$translate =App\Helpers\Menus::Translator(111)}}";
            }
        });

        // function toggleContent() {
        //     var contentText = document.querySelector(".read-more-target-2");
        //     contentText.classList.toggle("show-content-2");

        //     var button = document.getElementById("readMoreButton");
        //     if (contentText.classList.contains("show-content-2")) {
        //         button.innerHTML = "Read Less";
        //     } else {
        //         button.innerHTML = "Read More";
        //     }
        // }


        var language = $('#language').val();
        var search_form = $('#search_form').val();
        var select_dest = $('.select_dest').val();
        console.log(search_form, select_dest, language);
        /*const setUrl = (category_id, duration_id, budget_id, rating_id, activities_id, cities_id, inclusion_id, page, sort) => {
            let lang = urlParams.searchParams.get('lang') === null ? 'en' : urlParams.searchParams.get('lang');
            var newurl = window.location.protocol + "//" + window.location.host +
                window.location.pathname +

                    `?category=${category_id.length ? category_id : 'all'}${"&lang=" +
                lang}${duration_id[0].length ? '&duration=' + duration_id : ''}${budget_id[0].length ? '&budget=' +
                    budget_id : ''}${rating_id[0].length ? '&rating=' +
                    rating_id : ''}${activities_id[0].length ? '&activities=' +
                    activities_id : ''}${cities_id[0].length ? '&cities=' +
                    cities_id : ''}${inclusion_id[0].length ? '&inclusion=' +
                    inclusion_id : ''}${sort ? '&sort_by=' +
                    sort : ''}${'&page=' + page}`;
            window.history.pushState({
                path: newurl
            }, '', newurl);*/

        // $(".submit-form").click(function() {
        // }
        /*$(document).on('click', '.paginatebtn' , function () {
                    if (!search_form || !select_dest) {

                        $.ajax({
                            type: 'GET',
                            url: "{{ url('api/fetch-collection') }}" + `?page=${page}`,
                            data: {
                                // "_token": "{{ csrf_token() }}",
                                'category': category_id[0] != '' ? category_id : [],
                                'days': duration_id[0] != '' ? duration_id : [],
                                'price_ranges': budget_id[0] != '' ? budget_id : [],
                                'rating_id': rating_id[0] != '' ? rating_id : [],
                                'activities': activities_id[0] != '' ? activities_id : [],
                                'cities': cities_id[0] != '' ? cities_id : [],
                                'inclusion_id': inclusion_id[0] != '' ? inclusion_id : [],
                                'sort': sort ? sort : '',
                                'lang': language,
                            },
                            contentType: "application/json",
                            success: function (data) {
                                $('.product-grid').html(data);
                            }
                        });

                    }
                });
            */















        /*const urlParams = new URL(window.location.href);
            let category = urlParams.searchParams.get('category') === null ? null : [urlParams.searchParams.get(
                'category')];
            let duration = urlParams.searchParams.get('duration') === null ? null : [urlParams.searchParams.get(
                'duration')];
            let budget = urlParams.searchParams.get('budget') === null ? null : [urlParams.searchParams.get(
                'budget')];
            let rating = urlParams.searchParams.get('rating') === null ? null : [urlParams.searchParams.get(
                'rating')];
            let activities = urlParams.searchParams.get('activities') === null ? null : [urlParams.searchParams.get(
                'activities')];
            let inclusion = urlParams.searchParams.get('inclusion') === null ? null : [urlParams.searchParams.get(
                'inclusion')];
            let cities = urlParams.searchParams.get('cities') === null ? null : [urlParams.searchParams.get(
                'cities')];
            let page = urlParams.searchParams.get('page') === null ? 1 : urlParams.searchParams.get(
                'page');
            let sort = urlParams.searchParams.get('sort_by') === null ? null : urlParams.searchParams.get(
                'sort_by');


            setUrl(category, duration, budget, rating, activities, cities, inclusion, page, sort);
*/







        //
        // const selectOrder = document.querySelector('.select_order_by select');
        //
        // selectOrder.addEventListener('change', (event) => {
        //     console.log('game');
        //     const selectOrderValue = event.target.value;
        //     $('.product-grid').html("");
        //     var category_id = $("input[name='category_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var duration_id = $("input[name='duration_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var budget_id = $("input[name='budget_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var rating_id = $("input[name='rating_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var activities_id = $("input[name='activity_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var cities_id = $("input[name='cities_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //     var inclusion_id = $("input[name='inclusion_filter[]']:checked").map(function(item) {
        //         return this.value;
        //     }).get();
        //
        //     setUrl([category_id.toString()], [duration_id.toString()], [budget_id.toString()], [rating_id.toString()], [activities_id.toString()],
        //         [cities_id.toString()], [inclusion_id.toString()], 1, selectOrderValue);
        //     // Add code to do something with the selected value
        // });
        //
        //









        /* const categoryElement = document.querySelector('#category_id');

         categoryElement.addEventListener('change', (event) => {
             console.log('game');
             const categoryElementValue = event.target.value;
             $('.product-grid').html("");
             var category_id = $("input[name='category_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var duration_id = $("input[name='duration_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var budget_id = $("input[name='budget_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var rating_id = $("input[name='rating_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var activities_id = $("input[name='activity_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var cities_id = $("input[name='cities_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();
             var inclusion_id = $("input[name='inclusion_filter[]']:checked").map(function (item) {
                 return this.value;
             }).get();

             setUrl([category_id.toString()], [duration_id.toString()], [budget_id.toString()], [rating_id.toString()], [activities_id.toString()],
                 [cities_id.toString()], [inclusion_id.toString()], 1, categoryElementValue);
             // Add code to do something with the selected value
         });*/



        // commit by naveed
        //         $(document).on('click', '.paginatebtn', function() {
        //             var url = $(this).attr('data-url');
        //             $('.product-grid').html("");
        //             const urlParams = new URL(window.location.href);
        //
        //
        //             let category = urlParams.searchParams.get('category') !== null ? [''] : [urlParams.searchParams.get(
        //                 'category')];
        //             let duration = urlParams.searchParams.get('duration') === null ? [''] : [urlParams.searchParams.get(
        //                 'duration')];
        //             let budget = urlParams.searchParams.get('budget') === null ? [''] : [urlParams.searchParams.get(
        //                 'budget')];
        //             let rating = urlParams.searchParams.get('rating') === null ? [''] : [urlParams.searchParams.get(
        //                 'rating')];
        //             let activities = urlParams.searchParams.get('activities') === null ? [''] : [urlParams.searchParams.get(
        //                 'activities')];
        //             let inclusion = urlParams.searchParams.get('inclusion') === null ? [''] : [urlParams.searchParams.get(
        //                 'inclusion')];
        //             let cities = urlParams.searchParams.get('cities') === null ? [''] : [urlParams.searchParams.get(
        //                 'cities')];
        //             let sort = urlParams.searchParams.get('sort_by') === null ? [''] : [urlParams.searchParams.get(
        //                 'sort_by')];
        //
        //             setUrl(category, duration, budget, rating, activities, cities, inclusion, url.split('page=')[1], sort);
        //         });
        // commit by naveed end


        /*  $(".submit-form").change(function() {
              console.log('tested');
              $('.product-grid').html("");
              var category_id = $("input[name='category_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var duration_id = $("input[name='duration_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var budget_id = $("input[name='budget_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var rating_id = $("input[name='rating_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var activities_id = $("input[name='activity_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var cities_id = $("input[name='cities_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();
              var inclusion_id = $("input[name='inclusion_filter[]']:checked").map(function (item) {
                  return this.value;
              }).get();

              setUrl([category_id.toString()], [duration_id.toString()], [budget_id.toString()], [rating_id.toString()], [activities_id.toString()],
                  [cities_id.toString()], [inclusion_id.toString()], 1, sort);

          });*/

    });
</script>


{{--<script>--}}
{{-- // Commit by Naveed Ullah Sat Jun 2023-05-13--}}
{{-- {--}}
{{-- {--}}
{{-- --$(document).on('click', '.paginatebtn', function() {--}}
{{-- ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- ----}}
{{-- if (!search_form || !select_dest) {--}}
{{-- ----}}
{{-- }--}}
{{-- }--}}

{{-- {--}}
{{-- {--}}
{{-- --$.ajax({--}}
{{-- ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --type: 'GET', ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --url: "{{ url('api/fetch-collection') }}" + `?page=${page}`, ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --data: {--}}
{{-- ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- -- // "_token": "{{ csrf_token() }}",--}}
{{-- {--}}
{{-- {--}}
{{-- --'category': category_id[0] != '' ? category_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'days': duration_id[0] != '' ? duration_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'price_ranges': budget_id[0] != '' ? budget_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'rating_id': rating_id[0] != '' ? rating_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'activities': activities_id[0] != '' ? activities_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'cities': cities_id[0] != '' ? cities_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'inclusion_id': inclusion_id[0] != '' ? inclusion_id : [], ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'sort': sort ? sort : '', ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --'lang': language, ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- ----}}
{{-- }, ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --contentType: "application/json", ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --success: function(data) {--}}
{{-- ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- --$('.product-appends').html(data);--}}
{{-- ----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- ----}}
{{-- }----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- ----}}
{{-- });--}}
{{-- ----}}
{{-- }--}}
{{-- }--}}

{{-- {--}}
{{-- {--}}
{{-- ----}}
{{-- }----}}
{{-- }--}}
{{-- } {--}}
{{-- {--}}
{{-- ----}}
{{-- });--}}
{{-- ----}}
{{-- }--}}
{{-- }--}}
{{-- // Commit by Naveed Ullah Sat Jun 2023-05-13--}}
{{--</script>--}}




<script src="https://kit.fontawesome.com/b66d718ce1.js" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script type="js/custom.js"></script>

<script>
    function applyFilters(myVariable = null) {

            $('.preloader').show();
        var cities = [];
        var categories = [];
        var duration = [];
        var price_range = [];
        var rating = [];
        var activities = [];
        var cities = [];
        // var page = 1;
        // var select_order_by = '';
        // Get the selected checkboxes for cities
        // $('input[name="cities[]"]:checked').each(function () {
        //     cities.push($(this).val());
        // });

        // Get the selected checkboxes for categories
        $('input[name="category_filter[]"]:checked').each(function() {
            categories.push($(this).val());
        });

        // Get the selected checkboxes for price ranges
        $('input[name="duration_filter[]"]:checked').each(function() {
            duration.push($(this).val());
        });
        $('input[name="budget_filter[]"]:checked').each(function() {
            price_range.push($(this).val());
        });
        $('input[name="rating_filter[]"]:checked').each(function() {
            rating.push($(this).val());
        });
        $('input[name="activity_filter[]"]:checked').each(function() {
            activities.push($(this).val());
        });
        $('input[name="cities_filter[]"]:checked').each(function() {
            cities.push($(this).val());
        });

        var sort = $('.select_order_by select').val();

        if ($(myVariable).hasClass('paginatebtn')) {

            $('.paginatebtn').removeClass('active');
            $(myVariable).addClass('active');

        }
        var page = $('.paginatebtn.active').text();
        console.log(page);
        // Update the URL parameters
        var params = new URLSearchParams(window.location.search);
        // params.set('cities', cities.join(','));
        params.set('categories', categories.join(','));
        params.set('duration', duration.join(','));
        params.set('price_range', price_range.join(','));
        params.set('rating', rating.join(','));
        params.set('activities', activities.join(','));
        params.set('cities', cities.join(','));
        params.set('page', page);
        params.set('sort', sort);
        var newUrl = window.location.pathname + '?' + params.toString();
        window.history.replaceState({}, '', newUrl);

// Get the URL parameters
        var urlParams = new URLSearchParams(window.location.search);

// Get the value of the 'city' parameter
        var state = urlParams.get('state');
        // Send an AJAX request with the selected filter parameters
        $.ajax({
            url: "{{ url('api/fetch-collection') }}" + `?page=${page}`,
            type: 'GET',
            data: {
                price_range: price_range,
                categories: categories,
                duration: duration,
                rating: rating,
                activities: activities,
                cities: cities,
                page: page,
                sort: sort,
                state:state,
            },
            success: function(response) {
                // Handle the response and update the packages list
                $('.product-append').html(response);

                setTimeout(function() {
                    $('.preloader').hide();
                }, 200);
            },
            error: function(xhr) {
                // Handle the error if any
                console.log(xhr.responseText);
            }
        });
    }

    // Trigger the applyFilters function on checkbox change
    $('body').on('click', '.submit-form', function() {
        // applyFilters();
        var myVariable = $(this);

        applyFilters(myVariable);
    });
    $('body').on('change', '.submit-form-sort', function() {
        applyFilters();
    });


    // Trigger the applyFilters function on page load
    $(document).ready(function() {
        applyFilters();
        // setTimeout(function() {
        //     $('.preloader').hide();
        // }, 2000);

    });
</script>
@endsection
