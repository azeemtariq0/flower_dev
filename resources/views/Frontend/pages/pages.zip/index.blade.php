@extends('Frontend.layouts.master')
@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="lg-text">{{$pages->title ?? 'No Title Found'}}</h1>
            </div>
        </div>
    </div>
    </div>
    <div class="bread-bar">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-8">
                    <ol class="breadcrumb">
                        <li><a href="{{url('/')}}">Home</a></li>
                        <li class="active">{{$pages->title ?? 'No Title Found'}}</li>
                    </ol>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-4">
                </div>
            </div>
        </div>
    </div>
    <div class="aboutus-secktion paddingTB60">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h1 class="strong">{!! $pages->short_description ?? 'No Description Found' !!}</h1>
                </div>
                <div class="col-md-6">
                    <p>{!! $pages->long_description ?? 'No Description Found' !!}</p>
                </div>
            </div>
        </div>
    </div>
@endsection
