@extends('Frontend.layouts.master')
@section('content')
<style>
    /* .newslidercss>div .slick-track {
        display: contents !important;
    } */

    .tab-pane .row>div {
        height: 320px;
        overflow: hidden;
    }

    .get_explore {
        width: auto;
    }

    .full_width {
        width: 100%;
    }

    .row-h {
        display: flex;
        flex-wrap: wrap;
    }

    .justify-content-center {
        justify-content: center;
    }

    .justify-content-start {
        justify-content: start;
    }

    .border-1 {
        border: 1px solid #00000059;
    }

    .explore-form {}

    .my-checks {
        display: block;
        margin-bottom: 15px;
    }

    .view_all {
        top: 0 !important;
    }

    .p-3 {
        padding: 1rem !important;
    }

    .my-checks input {
        padding: 0;
        height: initial;
        width: initial;
        margin-bottom: 0;
        display: none;
        cursor: pointer;
    }

    .my-checks label {
        position: relative;
        cursor: pointer;
    }

    .my-checks label:before {
        content: '';
        -webkit-appearance: none;
        background-color: transparent;
        border: 1px solid #0079bf;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), inset 0px -15px 10px -12px rgba(0, 0, 0, 0.05);
        padding: 7px;
        display: inline-block;
        position: relative;
        vertical-align: middle;
        cursor: pointer;
        margin-right: 5px;
        border-radius: 2px;
        margin-block: auto;
    }

    .my-checks input:checked+label:after {
        content: '';
        display: block;
        position: absolute;
        top: 4px;
        left: 5px;
        width: 5px;
        height: 11px;
        border: solid #20a397;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
    }

    .dest_within_uae input:checked~label {
        color: #20a397;
    }

    .int_destinations input:checked~label {
        color: #20a397;
    }

    .int_destinations input:checked+.my-checks label:before {
        background: #20a397;
    }

    .text-abc {
        white-space: normal;
        overflow: hidden;
        line-height: 1.5em;
        height: 3em;
        text-overflow: ellipsis;
    }

    .active.days_limit {
        padding: 7.5px 7.44846px 8.5px 9.84842px;
        background: #E6542D;
        border-radius: 20px;
        color: #fff;
    }

    .days_limit.active a {
        color: #fff;

    }

    .days_limit.active a:after {
        opacity: 1;
    }

    .days_limit a {
        padding: 8px 7px;
    }

    .sec_destinations .slick-slide div img {
        width: 100%;
        height: 210px;
        object-fit: cover;
    }

    .themes_sec_inner {
        min-height: 122px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        gap: 2px;
    }

    .days_limit {
        padding: 0px !important
    }

    .p48 {
        padding: 48px !important;
    }

    .themes_sec_inner:hover {
        background: #f2f2f2;
    }

    .sbc5 {
        background-color: #f2f2f2;
    }

    .css-23ymlk {
        width: 72px;
        height: 72px;
    }

    .text-center {
        text-align: center;
    }

    .block {
        display: block !important;
    }

    .mauto {
        margin: 0 auto;
    }

    .relative {
        position: relative !important;
    }

    .mb0 {
        margin-bottom: 0 !important;
    }

    .mt15 {
        margin-top: 15px !important;
    }

    .fw9 {
        font-weight: 900;
    }

    .f16p {
        font-size: 16px;
        line-height: 24px;
    }

    .options li {
        text-align: start;
    }

    .spinner-border {
        --docsearch-text-color: #1c1e21;
        --docsearch-spacing: 12px;
        --docsearch-icon-stroke-width: 1.4;
        --docsearch-muted-color: #969faf;
        --docsearch-container-background: rgba(101, 108, 133, 0.8);
        --docsearch-modal-width: 560px;
        --docsearch-modal-height: 600px;
        --docsearch-modal-background: #f5f6f7;
        --docsearch-modal-shadow: inset 1px 1px 0 0 hsla(0, 0%, 100%, 0.5), 0 3px 8px 0 #555a64;
        --docsearch-searchbox-height: 56px;
        --docsearch-searchbox-background: #ebedf0;
        --docsearch-searchbox-focus-background: #fff;
        --docsearch-hit-height: 56px;
        --docsearch-hit-color: #444950;
        --docsearch-hit-active-color: #fff;
        --docsearch-hit-background: #fff;
        --docsearch-hit-shadow: 0 1px 3px 0 #d4d9e1;
        --docsearch-key-gradient: linear-gradient(-225deg, #d5dbe4, #f8f8f8);
        --docsearch-key-shadow: inset 0 -2px 0 0 #cdcde6, inset 0 0 1px 1px #fff, 0 1px 2px 1px rgba(30, 35, 90, 0.4);
        --docsearch-footer-height: 44px;
        --docsearch-footer-background: #fff;
        --docsearch-footer-shadow: 0 -1px 0 0 #e0e3e8, 0 -3px 6px 0 rgba(69, 98, 155, 0.12);
        --bs-blue: #0d6efd;
        --bs-indigo: #6610f2;
        --bs-purple: #6f42c1;
        --bs-pink: #d63384;
        --bs-red: #dc3545;
        --bs-orange: #fd7e14;
        --bs-yellow: #ffc107;
        --bs-green: #198754;
        --bs-teal: #20c997;
        --bs-cyan: #0dcaf0;
        --bs-black: #000;
        --bs-white: #fff;
        --bs-gray: #6c757d;
        --bs-gray-dark: #343a40;
        --bs-gray-100: #f8f9fa;
        --bs-gray-200: #e9ecef;
        --bs-gray-300: #dee2e6;
        --bs-gray-400: #ced4da;
        --bs-gray-500: #adb5bd;
        --bs-gray-600: #6c757d;
        --bs-gray-700: #495057;
        --bs-gray-800: #343a40;
        --bs-gray-900: #212529;
        --bs-primary: #0d6efd;
        --bs-secondary: #6c757d;
        --bs-success: #198754;
        --bs-info: #0dcaf0;
        --bs-warning: #ffc107;
        --bs-danger: #dc3545;
        --bs-light: #f8f9fa;
        --bs-dark: #212529;
        --bs-primary-rgb: 13, 110, 253;
        --bs-secondary-rgb: 108, 117, 125;
        --bs-success-rgb: 25, 135, 84;
        --bs-info-rgb: 13, 202, 240;
        --bs-warning-rgb: 255, 193, 7;
        --bs-danger-rgb: 220, 53, 69;
        --bs-light-rgb: 248, 249, 250;
        --bs-dark-rgb: 33, 37, 41;
        --bs-white-rgb: 255, 255, 255;
        --bs-black-rgb: 0, 0, 0;
        --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
        --bs-body-font-family: var(--bs-font-sans-serif);
        --bs-body-font-size: 1rem;
        --bs-body-font-weight: 400;
        --bs-body-line-height: 1.5;
        --bs-link-decoration: underline;
        --bs-border-width: 1px;
        --bs-border-style: solid;
        --bs-border-radius: 0.375rem;
        --bs-border-radius-sm: 0.25rem;
        --bs-border-radius-lg: 0.5rem;
        --bs-border-radius-xl: 1rem;
        --bs-border-radius-2xl: 2rem;
        --bs-border-radius-pill: 50rem;
        --bs-box-shadow: 0 0.5rem 1rem rgba(var(--bs-body-color-rgb), 0.15);
        --bs-box-shadow-sm: 0 0.125rem 0.25rem rgba(var(--bs-body-color-rgb), 0.075);
        --bs-box-shadow-lg: 0 1rem 3rem rgba(var(--bs-body-color-rgb), 0.175);
        --bs-box-shadow-inset: inset 0 1px 2px rgba(var(--bs-body-color-rgb), 0.075);
        --bs-form-control-bg: var(--bs-body-bg);
        --bs-highlight-bg: #fff3cd;
        --bs-breakpoint-xs: 0;
        --bs-breakpoint-sm: 576px;
        --bs-breakpoint-md: 768px;
        --bs-breakpoint-lg: 992px;
        --bs-breakpoint-xl: 1200px;
        --bs-breakpoint-xxl: 1400px;
        --bs-body-color: #adb5bd;
        --bs-body-color-rgb: 173, 181, 189;
        --bs-body-bg: #212529;
        --bs-body-bg-rgb: 33, 37, 41;
        --bs-emphasis-color-rgb: 248, 249, 250;
        --bs-secondary-color: rgba(173, 181, 189, 0.75);
        --bs-secondary-color-rgb: 173, 181, 189;
        --bs-secondary-bg: #343a40;
        --bs-secondary-bg-rgb: 52, 58, 64;
        --bs-tertiary-color: rgba(173, 181, 189, 0.5);
        --bs-tertiary-color-rgb: 173, 181, 189;
        --bs-tertiary-bg: #2b3035;
        --bs-tertiary-bg-rgb: 43, 48, 53;
        --bs-emphasis-color: #fff;
        --bs-primary-text: #6ea8fe;
        --bs-secondary-text: #dee2e6;
        --bs-success-text: #75b798;
        --bs-info-text: #6edff6;
        --bs-warning-text: #ffda6a;
        --bs-danger-text: #ea868f;
        --bs-light-text: #f8f9fa;
        --bs-dark-text: #dee2e6;
        --bs-primary-bg-subtle: #031633;
        --bs-secondary-bg-subtle: #212529;
        --bs-success-bg-subtle: #051b11;
        --bs-info-bg-subtle: #032830;
        --bs-warning-bg-subtle: #332701;
        --bs-danger-bg-subtle: #2c0b0e;
        --bs-light-bg-subtle: #343a40;
        --bs-dark-bg-subtle: #1a1d20;
        --bs-primary-border-subtle: #084298;
        --bs-secondary-border-subtle: #495057;
        --bs-success-border-subtle: #0f5132;
        --bs-info-border-subtle: #055160;
        --bs-warning-border-subtle: #664d03;
        --bs-danger-border-subtle: #842029;
        --bs-light-border-subtle: #495057;
        --bs-dark-border-subtle: #343a40;
        --bs-heading-color: #fff;
        --bs-link-color: #6ea8fe;
        --bs-link-hover-color: #9ec5fe;
        --bs-link-color-rgb: 110, 168, 254;
        --bs-link-hover-color-rgb: 158, 197, 254;
        --bs-code-color: #e685b5;
        --bs-border-color: #495057;
        --bs-border-color-translucent: rgba(255, 255, 255, 0.15);
        --bd-purple: #4c0bce;
        --bd-accent: #ffe484;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;
        --bd-accent-rgb: 255, 228, 132;
        --bd-pink-rgb: 214, 51, 132;
        --bd-teal-rgb: 32, 201, 151;
        --bd-violet: #9461fb;
        --bd-violet-bg: #712cf9;
        --bd-sidebar-link-bg: rgba(84, 33, 187, .5);
        --base00: #282c34;
        --base01: #353b45;
        --base02: #3e4451;
        --base03: #868e96;
        --base04: #565c64;
        --base05: #abb2bf;
        --base06: #b6bdca;
        --base07: #d19a66;
        --base08: #e06c75;
        --base09: #d19a66;
        --base0A: #e5c07b;
        --base0B: #98c379;
        --base0C: #56b6c2;
        --base0D: #61afef;
        --base0E: #c678dd;
        --base0F: #be5046;
        font-family: var(--bs-body-font-family);
        font-size: var(--bs-body-font-size);
        font-weight: var(--bs-body-font-weight);
        line-height: var(--bs-body-line-height);
        color: var(--bs-body-color);
        -webkit-text-size-adjust: 100%;
        -webkit-tap-highlight-color: transparent;
        --bs-gutter-y: 0;
        --bs-gutter-x: 3rem;
        --bd-example-padding: 1.5rem;
        box-sizing: border-box;
        display: inline-block;
        width: var(--bs-spinner-width);
        height: var(--bs-spinner-height);
        vertical-align: var(--bs-spinner-vertical-align);
        border-radius: 50%;
        animation: var(--bs-spinner-animation-speed) linear infinite var(--bs-spinner-animation-name);
        --bs-spinner-width: 2rem;
        --bs-spinner-height: 2rem;
        --bs-spinner-vertical-align: -0.125em;
        --bs-spinner-border-width: 0.25em;
        --bs-spinner-animation-speed: 0.75s;
        --bs-spinner-animation-name: spinner-border;
        border: var(--bs-spinner-border-width) solid currentcolor;
        border-right-color: transparent;
        margin-bottom: 0;
    }

    .spinner-border .visually-hidden {
        --docsearch-text-color: #1c1e21;
        --docsearch-spacing: 12px;
        --docsearch-icon-stroke-width: 1.4;
        --docsearch-muted-color: #969faf;
        --docsearch-container-background: rgba(101, 108, 133, 0.8);
        --docsearch-modal-width: 560px;
        --docsearch-modal-height: 600px;
        --docsearch-modal-background: #f5f6f7;
        --docsearch-modal-shadow: inset 1px 1px 0 0 hsla(0, 0%, 100%, 0.5), 0 3px 8px 0 #555a64;
        --docsearch-searchbox-height: 56px;
        --docsearch-searchbox-background: #ebedf0;
        --docsearch-searchbox-focus-background: #fff;
        --docsearch-hit-height: 56px;
        --docsearch-hit-color: #444950;
        --docsearch-hit-active-color: #fff;
        --docsearch-hit-background: #fff;
        --docsearch-hit-shadow: 0 1px 3px 0 #d4d9e1;
        --docsearch-key-gradient: linear-gradient(-225deg, #d5dbe4, #f8f8f8);
        --docsearch-key-shadow: inset 0 -2px 0 0 #cdcde6, inset 0 0 1px 1px #fff, 0 1px 2px 1px rgba(30, 35, 90, 0.4);
        --docsearch-footer-height: 44px;
        --docsearch-footer-background: #fff;
        --docsearch-footer-shadow: 0 -1px 0 0 #e0e3e8, 0 -3px 6px 0 rgba(69, 98, 155, 0.12);
        --bs-blue: #0d6efd;
        --bs-indigo: #6610f2;
        --bs-purple: #6f42c1;
        --bs-pink: #d63384;
        --bs-red: #dc3545;
        --bs-orange: #fd7e14;
        --bs-yellow: #ffc107;
        --bs-green: #198754;
        --bs-teal: #20c997;
        --bs-cyan: #0dcaf0;
        --bs-black: #000;
        --bs-white: #fff;
        --bs-gray: #6c757d;
        --bs-gray-dark: #343a40;
        --bs-gray-100: #f8f9fa;
        --bs-gray-200: #e9ecef;
        --bs-gray-300: #dee2e6;
        --bs-gray-400: #ced4da;
        --bs-gray-500: #adb5bd;
        --bs-gray-600: #6c757d;
        --bs-gray-700: #495057;
        --bs-gray-800: #343a40;
        --bs-gray-900: #212529;
        --bs-primary: #0d6efd;
        --bs-secondary: #6c757d;
        --bs-success: #198754;
        --bs-info: #0dcaf0;
        --bs-warning: #ffc107;
        --bs-danger: #dc3545;
        --bs-light: #f8f9fa;
        --bs-dark: #212529;
        --bs-primary-rgb: 13, 110, 253;
        --bs-secondary-rgb: 108, 117, 125;
        --bs-success-rgb: 25, 135, 84;
        --bs-info-rgb: 13, 202, 240;
        --bs-warning-rgb: 255, 193, 7;
        --bs-danger-rgb: 220, 53, 69;
        --bs-light-rgb: 248, 249, 250;
        --bs-dark-rgb: 33, 37, 41;
        --bs-white-rgb: 255, 255, 255;
        --bs-black-rgb: 0, 0, 0;
        --bs-font-sans-serif: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", "Noto Sans", "Liberation Sans", Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";
        --bs-font-monospace: SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
        --bs-gradient: linear-gradient(180deg, rgba(255, 255, 255, 0.15), rgba(255, 255, 255, 0));
        --bs-body-font-family: var(--bs-font-sans-serif);
        --bs-body-font-size: 1rem;
        --bs-body-font-weight: 400;
        --bs-body-line-height: 1.5;
        --bs-link-decoration: underline;
        --bs-border-width: 1px;
        --bs-border-style: solid;
        --bs-border-radius: 0.375rem;
        --bs-border-radius-sm: 0.25rem;
        --bs-border-radius-lg: 0.5rem;
        --bs-border-radius-xl: 1rem;
        --bs-border-radius-2xl: 2rem;
        --bs-border-radius-pill: 50rem;
        --bs-box-shadow: 0 0.5rem 1rem rgba(var(--bs-body-color-rgb), 0.15);
        --bs-box-shadow-sm: 0 0.125rem 0.25rem rgba(var(--bs-body-color-rgb), 0.075);
        --bs-box-shadow-lg: 0 1rem 3rem rgba(var(--bs-body-color-rgb), 0.175);
        --bs-box-shadow-inset: inset 0 1px 2px rgba(var(--bs-body-color-rgb), 0.075);
        --bs-form-control-bg: var(--bs-body-bg);
        --bs-highlight-bg: #fff3cd;
        --bs-breakpoint-xs: 0;
        --bs-breakpoint-sm: 576px;
        --bs-breakpoint-md: 768px;
        --bs-breakpoint-lg: 992px;
        --bs-breakpoint-xl: 1200px;
        --bs-breakpoint-xxl: 1400px;
        --bs-body-color: #adb5bd;
        --bs-body-color-rgb: 173, 181, 189;
        --bs-body-bg: #212529;
        --bs-body-bg-rgb: 33, 37, 41;
        --bs-emphasis-color-rgb: 248, 249, 250;
        --bs-secondary-color: rgba(173, 181, 189, 0.75);
        --bs-secondary-color-rgb: 173, 181, 189;
        --bs-secondary-bg: #343a40;
        --bs-secondary-bg-rgb: 52, 58, 64;
        --bs-tertiary-color: rgba(173, 181, 189, 0.5);
        --bs-tertiary-color-rgb: 173, 181, 189;
        --bs-tertiary-bg: #2b3035;
        --bs-tertiary-bg-rgb: 43, 48, 53;
        --bs-emphasis-color: #fff;
        --bs-primary-text: #6ea8fe;
        --bs-secondary-text: #dee2e6;
        --bs-success-text: #75b798;
        --bs-info-text: #6edff6;
        --bs-warning-text: #ffda6a;
        --bs-danger-text: #ea868f;
        --bs-light-text: #f8f9fa;
        --bs-dark-text: #dee2e6;
        --bs-primary-bg-subtle: #031633;
        --bs-secondary-bg-subtle: #212529;
        --bs-success-bg-subtle: #051b11;
        --bs-info-bg-subtle: #032830;
        --bs-warning-bg-subtle: #332701;
        --bs-danger-bg-subtle: #2c0b0e;
        --bs-light-bg-subtle: #343a40;
        --bs-dark-bg-subtle: #1a1d20;
        --bs-primary-border-subtle: #084298;
        --bs-secondary-border-subtle: #495057;
        --bs-success-border-subtle: #0f5132;
        --bs-info-border-subtle: #055160;
        --bs-warning-border-subtle: #664d03;
        --bs-danger-border-subtle: #842029;
        --bs-light-border-subtle: #495057;
        --bs-dark-border-subtle: #343a40;
        --bs-heading-color: #fff;
        --bs-link-color: #6ea8fe;
        --bs-link-hover-color: #9ec5fe;
        --bs-link-color-rgb: 110, 168, 254;
        --bs-link-hover-color-rgb: 158, 197, 254;
        --bs-code-color: #e685b5;
        --bs-border-color: #495057;
        --bs-border-color-translucent: rgba(255, 255, 255, 0.15);
        --bd-purple: #4c0bce;
        --bd-accent: #ffe484;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;
        --bd-accent-rgb: 255, 228, 132;
        --bd-pink-rgb: 214, 51, 132;
        --bd-teal-rgb: 32, 201, 151;
        --bd-violet: #9461fb;
        --bd-violet-bg: #712cf9;
        --bd-sidebar-link-bg: rgba(84, 33, 187, .5);
        --base00: #282c34;
        --base01: #353b45;
        --base02: #3e4451;
        --base03: #868e96;
        --base04: #565c64;
        --base05: #abb2bf;
        --base06: #b6bdca;
        --base07: #d19a66;
        --base08: #e06c75;
        --base09: #d19a66;
        --base0A: #e5c07b;
        --base0B: #98c379;
        --base0C: #56b6c2;
        --base0D: #61afef;
        --base0E: #c678dd;
        --base0F: #be5046;
        font-family: var(--bs-body-font-family);
        font-size: var(--bs-body-font-size);
        font-weight: var(--bs-body-font-weight);
        line-height: var(--bs-body-line-height);
        color: var(--bs-body-color);
        -webkit-text-size-adjust: 100%;
        -webkit-tap-highlight-color: transparent;
        --bs-gutter-y: 0;
        --bs-gutter-x: 3rem;
        --bd-example-padding: 1.5rem;
        --bs-spinner-width: 2rem;
        --bs-spinner-height: 2rem;
        --bs-spinner-vertical-align: -0.125em;
        --bs-spinner-border-width: 0.25em;
        --bs-spinner-animation-speed: 0.75s;
        --bs-spinner-animation-name: spinner-border;
        box-sizing: border-box;
        position: absolute !important;
        width: 1px !important;
        height: 1px !important;
        padding: 0 !important;
        margin: -1px !important;
        overflow: hidden !important;
        clip: rect(0, 0, 0, 0) !important;
        white-space: nowrap !important;
        border: 0 !important;
    }

    #more {
        display: none;
    }

    .filter-option {
        display: flex;
        align-items: center;
    }

    .btn .dropdown-toggle {
        display: flex;
        align-items: center;
    }

    @keyframes spinner-border {
        to {
            transform: rotate(360deg);
        }

        from {

            transform: rotate(0deg);
        }
    }

    .multi-select-dropdown {
        position: relative;
        width: 200px;
        display: flex;
        align-items: center;
        text-align: start;
        z-index: 999;
    }

    .open ul {
        display: block;
    }

    /* .selected-options {
                display: flex;
                flex-wrap: wrap;
                padding: 8px 12px;
                background-color: #fff;
                border: 1px solid #ccc;
                border-radius: 4px;
                cursor: pointer;
                } */

    .selected-option {
        width: 100%;
        margin-right: 26px;
        /* padding-block: 0px; */
    }

    .selected-options {
        padding-block: 0px !important;
    }

    .selected-option p {
        /* padding: 10px; */
        margin: 0;
    }

    .selected-option-list {
        display: flex;
        overflow: auto;
    }

    .selected-option-list::-webkit-scrollbar {
        display: none;
    }

    .options {
        display: none;
        position: absolute;
        top: 100%;
        left: 0;
        width: 100%;
        z-index: 1;
        padding: 0;
        margin: 0;
        list-style: none;
        background-color: #fff;
        border: 1px solid #ccc;
        border-top: none;le
        border-radius: 0 0 4px 4px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    }

    .options li label {
        /* padding: 8px 12px; */
        cursor: pointer;
        width: 100%;
        height: 100%;
        /* background: beige; */
        padding: 10px;
    }

    .options li:hover {
        background-color: #f2f2f2;
    }

    .select-dd li label input[type="checkbox"] {
        margin-right: 8px;
    }

    .select-dd li label input[type="hidden"] {
        /* display: none; */
    }

    @media screen and (max-width: 700px) {

        .select_duration {
            width: 80% !important;
            margin: 0 !important;
        }
    }

    /* .selected-options {
                padding: 0px !important;
                } */
    .getwayslider {
        height: 300px !important;
    }

    .getwayslider>div {
        width: 100%;
        height: 200px;
    }

    .getwayslider>div img {
        width: 100%;
        height: 100%;
        object-fit: cover;
    }

    .callback-btn {
        font-weight: 700;
        font-size: 14px;
        line-height: 16px;
        color: #000000 !important;
        padding: 16.5px 76.2359px 15.5px 76.4203px;
        height: 48px;
        background: #FFFFFF;
        border: 1px solid #FFFFFF;
        border-radius: 2px;
    }
ul.suggestionbar {
    position: absolute;
    background: #f6f6f6;
    z-index: 9999999999999;
    padding: 0;
    width: 100%;
    text-align: left;
    text-transform: capitalize;
}
ul.suggestionbar li {
    padding: 10px 20px;
    border-bottom: 2px solid white;
    list-style-type: none;
}
/* .select_dest {
    background: url(../images/location.png) no-repeat;
    background-position: 17px 14px;
    padding-left: 40px;
    text-transform: capitalize;
    height: 100%;
    border: 1px solid #d4d4d4;
} */

input:focus-visible {
    outline: none;
}
    @media (min-width: 1200px) {
        .container {
            width: 1000px;
        }
    }
</style>
<section class="sec main_sec section text-center" id="explore">
    <div class="container">
        <div class="row justify-content-center">

            <h1>
                {!!$translate =App\Helpers\Menus::Translator(125)!!}
            </h1>
            <p>{{$translate =App\Helpers\Menus::Translator(11)}}</p>
        </div>
        <div class="row justify-content-center">
            <div class="form_main_wrap">
                <form class="row-h justify-content-center" method="GET" action="https://pmediaweb.com/dev/dopaminetravel/public/tour-package/default">
                    <input type="hidden" name="_token" value="Ck9qOmrqfe0Hq5UJPDsaZmdx827y76UOZXXxcYNY">
                    <div class="select_dest">
                           <input class="input-field search-location" required type="text" name="slug" placeholder="{{$translate =App\Helpers\Menus::Translator(48)}}">
                        <div class="" style="position:relative;">
                            <ul class="suggestionbar"></ul>
                        </div>
                    </div>

                    <!--<select name="slug" id="option" class="select_dest" required="">-->
                    <!--    <option selected="" disabled="" value="">{{$translate =App\Helpers\Menus::Translator(48)}}</option>-->
                    <!--    <option value="al-aryam">Al Aryam</option>-->
                    <!--    <option value="al-awir">Al Awir</option>-->
                    <!--    <option value="phoenix">Phoenix</option>-->
                    <!--    <option value="tucson">Tucson</option>-->
                    <!--    <option value="mesa">Mesa</option>-->
                    <!--    <option value="dehiwala">Dehiwala</option>-->
                    <!--    <option value="negombo">Negombo</option>-->
                    <!--    <option value="kandy">Kandy</option>-->
                    <!--    <option value="anderson">Anderson</option>-->
                    <!--    <option value="bettles">Bettles</option>-->
                    <!--    <option value="cordova">Cordova</option>-->
                    <!--    <option value="fujairah">Fujairah</option>-->
                    <!--    <option value="ajman">Ajman</option>-->
                    <!--    <option value="summerside">Summerside</option>-->
                    <!--    <option value="charlottetown">Charlottetown</option>-->
                    <!--    <option value="alberton">Alberton</option>-->
                    <!--    <option value="prince-albert">Prince Albert</option>-->
                    <!--    <option value="moose-jaw">Moose Jaw</option>-->
                    <!--</select>-->


                    <div class="multi-select-dropdown select_duration select explore-form">
                        <div class="selected-options  ">
                            <div class="selected-option " id="selectop-none">
                                <p> {{$translate =App\Helpers\Menus::Translator(50)}}</p>
                            </div>
                            <div class="selected-option-list" id="padding-0"></div>
                        </div>
                        <ul class="options select-dd ">
                            <li>
                                <label>
                                    <input type="checkbox" name="option1" value="1-3">
                                    1 to 3 days
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" name="option2" value="4-6">4 to 6 days</label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" name="option3" value="7-9">7 to 9 days
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" name="option4" value="10-12">10 to 12 days</label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" name="option5" value="13-31">13 days or more
                                </label>
                            </li>
                            <li>
                                <label>
                                    <input type="checkbox" name="option5" value="">Not decided
                                </label>
                            </li>
                        </ul>
                        <input type="hidden" name="selected-option-values" value="">
                    </div>


                    <!-- <select name="days" class=" select_duration">
                            <option selected disabled>Select duration</option>
                            <option value="1-3" data-content="<input type='checkbox' id='1to3'>">13 </option>
                            <option value="4-6">4 to 6 days</option>
                            <option value="7-9">7 to 9 days</option>
                            <option value="10-12">10 to 12 days</option>
                            <option value="13-31">13 days or more</option>
                            <option value="">Not decided</option>
                        </select> -->
                    <select name="month" class="select_month">
                        <option selected="" disabled="">{{$translate =App\Helpers\Menus::Translator(49)}}</option>
                        <option value="Mar">Mar
                            , 2023
                        </option>
                        <option value="Apr">Apr
                            , 2023
                        </option>
                        <option value="Jul">Jul
                            , 2023
                        </option>
                        <option value="Dec">Dec
                            , 2023
                        </option>
                        <option value="Feb">Feb
                            , 2023
                        </option>
                        <option value="Jun">Jun
                            , 2023
                        </option>
                        <option value="Sep">Sep
                            , 2023
                        </option>
                        <option value="Nov">Nov
                            , 2023
                        </option>
                        <option value="May">May
                            , 2023
                        </option>
                        <option value="Aug">Aug
                            , 2023
                        </option>
                        <option value="Jan">Jan
                            , 2023
                        </option>
                        <option value="">Not decided</option>
                    </select>
                    <input type="hidden" name="lang" id="lang" value="en">
                    <input type="hidden" name="search_form" id="search_form" value="search_form">
                    <input type="submit" name="submit" value="{{$translate =App\Helpers\Menus::Translator(58)}}">
                </form>
                <div class="dedtination_not_sure text-left">{{$translate =App\Helpers\Menus::Translator(95)}}
                    <a href="#packages">{{$translate =App\Helpers\Menus::Translator(96)}}</a>
                </div>
            </div>
        </div>
    </div>

</section>
<div class="sec sec_destinations section" id="destinations">

    <div class="container">
        <div class="row row-center">
            <div class="col-sm-6 explore">{{$translate =App\Helpers\Menus::Translator(12)}}</div>

            <div class="col-sm-6 bets_package_note"><img src="{{ asset('travel/images/phone.png') }}"> {{$translate =App\Helpers\Menus::Translator(51)}}
                <a href="tel:{{$translate =App\Helpers\Menus::Translator(120)}}">{{$translate =App\Helpers\Menus::Translator(120)}}</a>
            </div>
        </div>
        <div class="row row_destinations slider_destinations">
            @if(isset($theme))
            @foreach ($theme as $value)
            <div class="col-sm-2">
                <div>
                    @if ($value->image != null)
                    @php $image = '/'.$value->image @endphp
                    @else
                    @php $image = 'galleryimage.png' @endphp
                    @endif
                    <img style="" src="{{ asset('images/media' . '/' . $image) }}">
                    <a class="see-details-button absolute-center" href="{{url(app()->getLocale().'/'.$value->slug)}}">View
                        Detail</a>
                </div>
                <h3>{{$value->title ?? ''}}</h3>
                <p>{{$translate =App\Helpers\Menus::Translator(59)}}</p>
            </div>
            @endforeach
            @endif
        </div>

        <div class="row row_explore_selling" id="selling">
            <div class="explore_for_heading">{{$translate =App\Helpers\Menus::Translator(13)}}</div>
            <div class="select_sell_for sellingpkg ">
                <div class="my-checks int_destinations destination">
                    <input type="checkbox" name="sell_for" value="international" id="flexCheckDefault">
                    <label for="flexCheckDefault"> {{$translate =App\Helpers\Menus::Translator(25)}}</label>
                </div>

                <div class="my-checks dest_within_uae destination">
                    <input type="checkbox" name="sell_for" value="United Arab Emirates" id="uae">
                    <label for="uae"> {{$translate =App\Helpers\Menus::Translator(26)}}</label>
                </div>
            </div>
        </div>
        <div class="all_destinations" style="">
            <div class="days_main_wrap nav nav-tabs">
                <div class="days_limit selling "><a class="filter" data-value="1-3">1
                        to 3 days</a></div>
                <div class="days_limit selling active"><a class="filter" data-value="4-6">4
                        to 6 days</a></div>
                <div class="days_limit selling"><a class="filter" data-value="7-9">7
                        to 9 days</a></div>
                <div class="days_limit selling"><a class="filter" data-value="10-12">{{$translate =App\Helpers\Menus::Translator(55)}}</a>
                </div>
                <div class="days_limit selling"><a class="filter" data-value="13-100">13
                        or more days</a></div>
            </div>
            <div class="">
                <div id="explore_1_3">
                    <div class="row newslidercss row_destinations_packages packages-view slider_destinations vvvv ">
                        @include('Frontend/snippets/search-selling')
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<section class="sec sec_holidays section">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="heading1">{{$translate =App\Helpers\Menus::Translator(60)}}</div>
                <div class="heading2">{{$translate =App\Helpers\Menus::Translator(63)}}</div>
                <div class="heading3">{!!$translate =App\Helpers\Menus::Translator(14)!!}</div>
                <div class="heading4">in <span>{{$translate =App\Helpers\Menus::Translator(61)}}</span></div>
                <!-- {{$translate =App\Helpers\Menus::Translator(62)}} -->
                <div class="watch_video"><a data-fancybox="gallery" href="https://youtu.be/2G6hYuXIaR8"> {{$translate =App\Helpers\Menus::Translator(62)}} </a>
                </div>
            </div>

            <div class="col-sm-7">
                <div class="row text-center select_pkg">
                    <div class="col-sm-4">
                        <div class="select_pkg_img"><img src="{{ asset('travel/images/element1.png') }}"></div>
                        <h3>{{$translate =App\Helpers\Menus::Translator(32)}}</h3>
                        <p>{{$translate =App\Helpers\Menus::Translator(33)}}</p>
                    </div>

                    <div class="col-sm-4">
                        <div class="select_pkg_img"><img src="{{ asset('travel/images/element2.png') }}"></div>
                        <h3>{{$translate =App\Helpers\Menus::Translator(32)}}</h3>
                        <p>{{$translate =App\Helpers\Menus::Translator(33)}}</p>
                    </div>

                    <div class="col-sm-4">
                        <div class="select_pkg_img"><img src="{{ asset('travel/images/element3.png') }}"></div>
                        <h3>{{$translate =App\Helpers\Menus::Translator(32)}}</h3>
                        <p>{{$translate =App\Helpers\Menus::Translator(33)}}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="sec happy section" id="travel_stories">
    <div class="container">
        <h1>{{$translate =App\Helpers\Menus::Translator(123)}}</h1>
        <p>{{$translate =App\Helpers\Menus::Translator(27)}}</p>
    </div>
    <div class="container">
        <div class="row">
            <div>
                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#tab1">{{$translate =App\Helpers\Menus::Translator(64)}}</a>
                    </li>
                    <li><a data-toggle="tab" href="#tab2">{{$translate =App\Helpers\Menus::Translator(65)}}</a></li>
                    <li><a data-toggle="tab" href="#tab3">{{$translate =App\Helpers\Menus::Translator(66)}}</a></li>
                    <li><a data-toggle="tab" href="#tab4">{{$translate =App\Helpers\Menus::Translator(67)}}</a></li>
                    <li><a data-toggle="tab" href="#tab5">{{$translate =App\Helpers\Menus::Translator(68)}}</a></li>
                    <li><a data-toggle="tab" href="#tab6">{{$translate =App\Helpers\Menus::Translator(69)}}</a></li>
                    <li><a data-toggle="tab" href="#tab7">{{$translate =App\Helpers\Menus::Translator(70)}}</a></li>
                    <li>
                        <a href="{{ url('https://client.edwomtech.com/dopaminetravel_wp/') }}">{{$translate =App\Helpers\Menus::Translator(109)}}</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div id="tab1" class="tab-pane fade in active">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab1 ">
                                    <div class="col-sm-6"><img loading="lazy" src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img loading="lazy" src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img loading="lazy" src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img loading="lazy" src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(68)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>{{$translate =App\Helpers\Menus::Translator(72)}}</p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a>
                                    </div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab2" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab2">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>
                                    {{$translate =App\Helpers\Menus::Translator(72)}}
                                </p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a>
                                    </div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab3" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab3">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>{{$translate =App\Helpers\Menus::Translator(72)}}</p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a></div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab4" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab4">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>
                                    {{$translate =App\Helpers\Menus::Translator(72)}}
                                </p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a></div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div id="tab5" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab5">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>{{$translate =App\Helpers\Menus::Translator(72)}}</p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a></div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="tab6" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab6">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>{{$translate =App\Helpers\Menus::Translator(72)}}</p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a></div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div id="tab7" class="tab-pane fade">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="row slider_inside_tab slider_inside_tab7">
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/1.png') }}"></div>
                                    <div class="col-sm-6"><img src="{{ asset('travel/images/2.png') }}"></div>
                                </div>
                            </div>
                            <div class="col-sm-6 tab_data">
                                <h3>{{$translate =App\Helpers\Menus::Translator(16)}}</h3>
                                <div class="tags">
                                    <span>{{$translate =App\Helpers\Menus::Translator(75)}}</span><span>{{$translate =App\Helpers\Menus::Translator(76)}}</span><span>{{$translate =App\Helpers\Menus::Translator(77)}}</span><span>{{$translate =App\Helpers\Menus::Translator(78)}}</span>
                                </div>
                                <p>{{$translate =App\Helpers\Menus::Translator(72)}}</p>
                                <div class="row tab_row1">
                                    <div class="col-sm-1 nopad"><img src="{{ asset('travel/images/image006.png') }}">
                                    </div>
                                    <div class="col-sm-7">
                                        <h5>{{$translate =App\Helpers\Menus::Translator(79)}}</h5>
                                        <p>{{$translate =App\Helpers\Menus::Translator(80)}}</p>
                                    </div>
                                    <div class="col-sm-4 pull-right right_text">{{$translate =App\Helpers\Menus::Translator(81)}}</div>
                                </div>
                                <div class="row tab_row2">
                                    <div class="col-sm-4"><a href="#">{{$translate =App\Helpers\Menus::Translator(82)}}</a></div>
                                    <div class="col-sm-8 nopad"><a href="#" class="btn1">{{$translate =App\Helpers\Menus::Translator(83)}}</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</section>
<section class="sec section perfect_holiday">
    <div class="container">
        <div class="row">
            <h3 class="common text-center">{{$translate =App\Helpers\Menus::Translator(17)}}</h3>
            <p class="common text-center">{{$translate =App\Helpers\Menus::Translator(28)}}</p>
        </div>
        <div class="row external_btns text-center">
            <div class="col-sm-4">
                <a href="#selling">{{$translate =App\Helpers\Menus::Translator(84)}}</a>
            </div>
            <div class="col-sm-4">
                <a href="#packages">{{$translate =App\Helpers\Menus::Translator(85)}}</a>
            </div>
            <div class="col-sm-4">
                <a href="#get_a_free_quote">{{$translate =App\Helpers\Menus::Translator(86)}}</a>
            </div>
        </div>
        <div class="row row_last_holidya_perfect">
            <div class="col-sm-6">
                <h4>{{$translate =App\Helpers\Menus::Translator(24)}}</h4>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon1.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(87)!!}</h5>
                    </div>

                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon2.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(88)!!}</h5>
                    </div>

                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon3.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(89)!!}</h5>
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <h4>{{$translate =App\Helpers\Menus::Translator(121)}}</h4>
                <div class="row">
                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon4.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(90)!!}</h5>
                    </div>

                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon5.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(91)!!}</h5>
                    </div>

                    <div class="col-sm-4">
                        <img src="{{ asset('travel/images/icon6.png') }}">
                        <h5>{!!$translate =App\Helpers\Menus::Translator(92)!!}</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container simple_filters" id="packages">
        <div class="row">
            <h3 class="common text-center">{{$translate =App\Helpers\Menus::Translator(20)}}</h3>
            <p class="common text-center">{{$translate =App\Helpers\Menus::Translator(29)}}</p>
        </div>
        <div class="all_destinations">
            <h4>{{$translate =App\Helpers\Menus::Translator(30)}}</h4>
            <div class="price_main_wrap  nav nav-tabs">
                <div class="days_limit price "><a class="filter" data-value="0-1000">Less than AED 1000</a>
                </div>
                <div class="days_limit price"><a class="filter" data-value="1000-2000">AED 1000 to AED
                        2000</a>
                </div>
                <div class="days_limit price"><a class="filter" data-value="2000-4000">AED 2000 to AED
                        4000</a>
                </div>
                <div class="days_limit price active"><a class="filter" data-value="4000-6000">AED 4000 to AED
                        6000</a>
                </div>
                <div class="days_limit price"><a class="filter" data-value="6000-8000">AED 6000 to AED
                        8000</a>
                </div>
                <div class="days_limit price"><a class="filter" data-value="8000-100000000000">Above AED
                        8000</a>
                </div>
            </div>

            <div>
                <div id="explore_10_less">
                    <div class="total_packges_with_slider">
                        <div class="sec_red_price">You have {{count($package)}} packages
                            <div class="view_all"><a href="#">{{$translate =App\Helpers\Menus::Translator(109)}}</a>

                            </div>

                        </div>
                        <div class="slider_red_price row packages-view">
                            @include('Frontend/snippets/search-price')
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div class="text-center">
            <img class="full_width" src="{{asset('images/media'.'/'.$honeymoon_image->image)}}">
        </div>
        <div class="slider_red_2">
            <div class="all_destinations">
                <h4>{{$translate =App\Helpers\Menus::Translator(18)}}</h4>
                <div class="best_main_wrap nav nav-tabs">
                    <div type="radio" class="days_limit best active"><a class="filter" data-value="1-3">{{$translate =App\Helpers\Menus::Translator(52)}}</a>
                    </div>
                    <div type="radio" class="days_limit best"><a class="filter" data-value="4-6">{{$translate =App\Helpers\Menus::Translator(53)}}</a>
                    </div>
                    <div type="radio" class="days_limit best"><a class="filter" data-value="7-9">{{$translate =App\Helpers\Menus::Translator(54)}}</a>
                    </div>
                    <div type="radio" class="days_limit best"><a class="filter" data-value="10-12">{{$translate =App\Helpers\Menus::Translator(55)}}</a>
                    </div>
                    <div type="radio" class="days_limit best"><a class="filter" data-value="13-100">{{$translate =App\Helpers\Menus::Translator(56)}}</a>
                    </div>
                </div>
                <div>
                    <div id="duration_1">
                        <div class="">
                            <div class="sec_red_price">You have {{count($package)}} packages
                                <div class="view_all"><a href="#">{{$translate =App\Helpers\Menus::Translator(109)}}</a>
                                </div>
                            </div>

                            <div class=" row packages-view slider_red_price">
                                @include('Frontend/snippets/search-best')

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <h4 class="select_travel_month_heading">{{$translate =App\Helpers\Menus::Translator(31)}}</h4>
        <h5 class=""><span>{{$translate =App\Helpers\Menus::Translator(93)}}</span></h5>
        <div class="all_destinations">
            <div class="month_main_wrap best_main_wrap nav nav-tabs">
                <div type="radio" class="month days_limit"><a class="filter" data-value="Jan-Feb-Mar">Jan-Feb-Mar</a></div>
                <div type="radio" class="month days_limit"><a class="filter" data-value="Apr-May-Jun">Apr-May-Jun</a></div>
                <div type="radio" class="month days_limit active" checked ><a class="filter" data-value="Jul-Aug-Sep">Jul-Aug-Sep</a></div>
                <div type="radio" class="month days_limit"><a class="filter" data-value="Oct-Nov-Dec">Oct-Nov-Dec</a>
                </div>
            </div>

            <div style="
                margin-top: 3em;
            ">
                <div id="jan">
                    <div class="row packages-view slider_red_price">
                        @include('Frontend/snippets/search-month')
                    </div>
                </div>

            </div>
        </div>
        <div class="themes_sec">
            <h6>{{$translate =App\Helpers\Menus::Translator(97)}}</h6>
            <h4 class="select_travel_month_heading">{{$translate =App\Helpers\Menus::Translator(15)}}</h4>

            <div class="row text-center row_themes">
                @if(isset($activities))
                @foreach ($activities as $activity)
                <div class="col-sm-3">
                    <a class="themes_sec_inner" href="{{url(app()->getLocale().'/tour-packages')}}?activities={{$activity->slug}}">
                        @if ($activity->image != null)
                        @php $image = $activity->image @endphp
                        @else
                        @php $image = 'galleryimage.png' @endphp
                        @endif
                        <img src="{{ asset('images/media' . '/' . $image) }}">
                        <p><strong>{{ $activity->title ?? ''}}</strong>
                            <br>{{$translate =App\Helpers\Menus::Translator(94)}}
                        </p>
                    </a>
                </div>
                @endforeach
                @endif
            </div>
        </div>
    </div>
</section>
<section class="sec section sec_excerpt" id="get_a_free_quote">
    <div class="container">
        <div class="row row-h index-form-parent">
            <div class="col-sm-6 text-center form-left-img">
                <img src="{{ asset('travel/images/feeling_lost.png') }}">
                <h1>{{$translate =App\Helpers\Menus::Translator(34)}}</h1>
                <p>{{$translate =App\Helpers\Menus::Translator(35)}}</p>
            </div>

            <div class="col-sm-6 border-1 index-form">
                @include('Frontend/snippets/form-modal')
            </div>
        </div>
    </div>
</section>
<section class="sec section safe_holidays">
    <div class="container">
        <h4 class="common">{{$translate =App\Helpers\Menus::Translator(36)}}</h4>
        <p class="common2">{{$translate =App\Helpers\Menus::Translator(37)}}</p>
        <div class="row">
            @if(isset($holidays))
            @foreach ($holidays as $holiday)
            <div class="col-sm-3 commitment-desc">
                @if ($holiday->image != null)
                @php $image = $holiday->image @endphp
                @else
                @php $image = 'galleryimage.png' @endphp
                @endif
                <img src="{{ asset('images/media' . '/' . $image) }}">
                <h5>{{ $holiday->title }}</h5>
                <p>{!! $holiday->description !!}</p>
            </div>
            @endforeach
            @endif
        </div>
    </div>
</section>
<section class="sec section text-center generic_large">
    <div class="container">
        <a href="{{url(app()->getLocale().'/tour-packages')}}"><img src="{{asset('images/media'.'/'.$holiday_image->image)}}" class="full_width"></a>
    </div>
</section>
<section class="sec section incredibly_sec">
    <div class="container">

        <div class=" incredibly_text">

            <h3> {{$translate =App\Helpers\Menus::Translator(39)}}</h3>
            <div class="sec_red_price">You have 4 packages
                <div class="view_all"> <a href="https://pmediaweb.com/dev/dopaminetravel_wp/" target="_blank">{{$translate =App\Helpers\Menus::Translator(109)}}</a>


                </div>

            </div>

        </div>

        <div class="row incredibly_slider text-center">
            @foreach($blogs as $blog)
            <div class="col-sm-4 getwayslider">
                <div class="incredibly_slider_inner">
                    <img src="{{$blog->thumbnail_url}}">
                    <h4>{{$blog->title}}</h4>
                    <p class="pull-right">
                        <a href="#">{{$translate =App\Helpers\Menus::Translator(111)}}</a>
                    </p>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
<section class="sec section get_explore">
    <div class="row">
        <div class="col-sm-8">
            <h3>{{$translate =App\Helpers\Menus::Translator(40)}}</h3>
            <p>{{$translate =App\Helpers\Menus::Translator(41)}}</p>
        </div>
        <div class="col-sm-4">
            <button id="quotesBtn" class="callback-btn">{{$translate =App\Helpers\Menus::Translator(112)}}</button>
        </div>
    </div>

</section>
<section class="sec section who_we_are">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-left">
                <h3>{{$translate =App\Helpers\Menus::Translator(42)}}</h3>
                <p>{{$translate =App\Helpers\Menus::Translator(113)}}<span id="dots">...</span></p>
                <div id="more">
                    <p>{{$translate =App\Helpers\Menus::Translator(114)}}</p>

                    <p>{{$translate =App\Helpers\Menus::Translator(115)}}</p>

                    <p>{{$translate =App\Helpers\Menus::Translator(116)}}</p>

                    <p>{{$translate =App\Helpers\Menus::Translator(117)}}</p>

                    <p>{{$translate =App\Helpers\Menus::Translator(118)}}</p>
                </div>
                <p class="pull-right"><a href="#" id="myBtn" onclick="readmore()">{{$translate =App\Helpers\Menus::Translator(111)}}</a>
                </p>
            </div>
        </div>
    </div>
</section>
</div>
<div id="quotesmyModal" class="popup">
    <div class="popup-content">
        <div class=" quotesclose-div">

            <img src="{{asset('images/dopamine/sa.svg#CloseWhite-usage')}}  " class=" quotesclose" alt="">
        </div>

        <!-- <span class="quotesclose">&times;</span> -->
        <div class="popup-clearfix">
            <h4 class="location_heading ">How It Works</h4>
            <div class="textes">
                <ul>
                    <li>
                        <span class="round-bullets ">1</span>
                        <p>Tell us details of your holiday plan.</p>
                    </li>
                    <li>
                        <span class="round-bullets">2</span>
                        <p>Get multiple quotes from expert agents, compare &amp; customize further.</p>
                    </li>
                    <li>
                        <span class="round-bullets ">3</span>
                        <p>Select &amp; book best deal.</p>
                    </li>
                </ul>
            </div>
            <div class="box3">
                <div class="card">
                    <img src="{{asset('images/dopamine/sa.svg#IllusAgent-usage')}}  " class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">650+</h4>
                        <p class="para">Verified Agents</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{asset('images/dopamine/na.svg#IllusMoneySafe-usage')}} " class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">Traveltriangle</h4>
                        <p class="para">Verified</p>
                    </div>
                </div>
                <div class="card">
                    <img src="{{asset('images/dopamine/na.svg#IllusQualityCheck-usage')}}" class="svg" alt="">
                    <div class="how-it-img">
                        <h4 class="card-text">Stringent</h4>
                        <p class="para">Quality Control</p>
                    </div>
                </div>
            </div>
            <hr class="bb">

            <div class="call-detail">
                <span class="icon">
                    <img src="WhatsApp Image 2023-05-13 at 1.45.31 AM (1).jpeg" class="icon" alt="">
                </span>
                <span class="para">Call Us for details</span>
            </div>
            <h3 class="location_heading">
                1800-123-5555</h3>
            <p class="text-center ">650+ Agents | 40 Lac+ Travelers | 65+ Destinations</p>


        </div>
        <div class="form-popup">
            @include('Frontend/snippets/form-package')


        </div>


    </div>

</div>
<div class="vertical_page_tabing">
    <a href="#explore">Explore</a>
    <a href="#destinations">Destinations</a>
    <a href="#travel_stories">Travel Stories</a>
    <a href="#packages">Packages</a>
    <a href="#get_a_free_quote">Get a Free Quote</a>
</div>
<input type="hidden" name="lang_id" id="language_id" value="{{app()->getLocale()}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(".submit-form").click(function() {
        $('.vvvv').html("");
        var sell_for = $("input[name='sell_for']:checked").map(function(item) {
            return $(this).val();
        }).get();
        var lang_id = $('#language_id').val();
        console.log(sell_for, lang_id);
        $.ajax({
            type: 'GET',
            url: "{{url('destination')}}",
            data: {
                "_token": "{{ csrf_token() }}",
                'sell_for': sell_for,
                'lang_id': lang_id,
            },
            contentType: "application/json",
            success: function(data) {
                $('.slider_destinations').slick('unslick');
                $('.vvvv').html(data);

                setTimeout(function() {
                    $('.slider_destinations').slick({
                        slidesToShow: 6,
                        slidesToScroll: 1,
                        arrows: true,
                        autoplay: true,


                    });
                }, 3000);
            }
        });
    });
</script>


<script>
    $(".destination").click(function() {
        $('.vvvv').html("");
        var search_selling = $('.days_limit.selling.active').find('a').data('value');
        var sell_for = $("input[name='sell_for']:checked").map(function(item) {
            return $(this).val();
        }).get();
        var lang_id = $('#language_id').val();
        $.ajax({
            type: 'GET',
            url: "{{ url(app()->getLocale().'/f/filter')}}",
            data: {
                "_token": "{{ csrf_token() }}",
                'sell_for': sell_for,
                'search_selling':search_selling,
                'lang_id': lang_id,
            },
            contentType: "application/json",
            success: function(data) {
                console.log('fff');
                // $('.slider_destinations').slick('unslick');
                $('.vvvv').html(data);

                // setTimeout(function() {
                //     $('.slider_destinations').slick({
                //         slidesToShow: 6,
                //         slidesToScroll: 1,
                //         arrows: true,
                //         autoplay: true,
                //         responsive: [{
                //                 breakpoint: 1100,
                //                 settings: {
                //                     slidesToShow: 5,
                //                     slidesToScroll: 1,
                //                     infinite: true,
                //                     dots: true
                //                 }
                //             },
                //             {
                //                 breakpoint: 800,
                //                 settings: {
                //                     slidesToShow: 4,
                //                     slidesToScroll: 1
                //                 }
                //             },
                //             {
                //                 breakpoint: 480,
                //                 settings: {
                //                     slidesToShow: 1,
                //                     slidesToScroll: 1
                //                 }
                //             }
                //         ]
                //
                //     });
                // }, 500);
            }
        });
    });
</script>


<script>
    $(document).ready(function() {

        $(document).on('click', '.filter', function() {
            $(this).parents('.all_destinations').find('.days_limit').removeClass('active');
            $(this).parents('.days_limit').addClass('active');
            // $(this).parents('.all_destinations').find('.packages-view div').css({'opacity':'0'})
            console.log(
                "eeeeeeeeeeeeeeeeeee"
            )
            $(this).parents('.all_destinations').find('.packages-view').html(`<div class="col-12 py-4 text-center" style="
    padding-block: 2em;
">
<div role="status" class="spinner-border" style="
    width: 30px;
    height: 30px;
    color: #e6542d;
">
  <span class="visually-hidden">Loading...</span>
</div>
</div>`);
            var $value1 = null;
            var $value2 = null;
            var $value3 = null;
            var $value4 = null;
            var $lang_id = $('#language_id').val();
            if ($(this).parents('.price_main_wrap').find('.price').length) {
                $value1 = $(this).data('value');
            }
            if ($(this).parents('.month_main_wrap').find('.month').length) {
                $value2 = $(this).data('value');
            }
            if ($(this).parents('.best_main_wrap').find('.best').length) {
                $value3 = $(this).data('value');
            }
            if ($(this).parents('.days_main_wrap').find('.selling').length) {
                $value4 = $(this).data('value');
            }
            var sell_for = $("input[name='sell_for']:checked").map(function(item) {
                return $(this).val();
            }).get();

            var itt = this;
            //ajax_filter
            $.ajax({
                type: 'GET',
                url: "{{ url(app()->getLocale().'/f/filter')}}",
                data: {
                    "_token": "{{ csrf_token() }}",
                    'search_price': $value1,
                    'search_month': $value2,
                    'search_best': $value3,
                    'search_selling': $value4,
                    'sell_for': sell_for,
                    'lang_id': $lang_id,
                },
                contentType: "application/json",
                success: function(data) {
                    if (data === '') {
                        $(itt).parents('.all_destinations').find('.packages-view').html(`<div class="p48 sbc5"><span class="relative block mauto text-center css-23ymlk">   <img src="{{asset('images/dopamine/home.jpeg')}} " class="svg" alt="" style="object-fit: contain;"></span><p class="f16p fw9 mt15 mb0 text-center">Couldn't find any destination. Try other duration.</p></div>`);

                    } else {
                        console.log(data);
                        $(itt).parents('.all_destinations').find('.packages-view').html(data);
                        // initSlickCarousel();
                    }
                    setTimeout(function() {

                    }, 3000);


                },
                error: function(err) {
                    console.error(err)
                }

            });
        });
    });
</script>
<script type="text/javascript">
    jQuery('.select_travel_month_below a').click(function() {

        // jQuery(this).addClass('hli').find('input').prop('checked', true)
    });
    jQuery(document).ready(function() {
        jQuery(".int_destinations").click(function() {
            jQuery(".aaaaaaaa").show();
            // jQuery(".destinations_within_uae").hide();
            // jQuery(".internationa_destinations").show();
            // jQuery(this).addClass('hlii').find('input').prop('checked', true)
        });
        jQuery(".dest_within_uae").click(function() {
            jQuery(".aaaaaaaa").show();
            // jQuery(".internationa_destinations").hide();
            // jQuery(".destinations_within_uae").show();
            // jQuery(this).addClass('hlii').find('input').prop('checked', true)
        });

        // jQuery(".has-sub > a").append('<i class="fa fa-chevron-down"></i>');
        // jQuery(".sec_excerpt .submit").append('<i class="fa fa-chevron-right"></i>');
    });
    var coll = document.getElementsByClassName("collapsible");
    var i;
    for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
                content.style.display = "none";
            } else {
                content.style.display = "block";
            }
        });
    }
    jQuery("document").ready(function() {
        jQuery(".collapsible").trigger('click');
    });
</script>
<script>
    function readmore() {
        var dots = document.getElementById("dots");
        var moreText = document.getElementById("more");
        var btnText = document.getElementById("myBtn");

        if (dots.style.display === "none") {
            dots.style.display = "inline";
            btnText.innerHTML = "Read more";
            moreText.style.display = "none";
        } else {
            dots.style.display = "none";
            btnText.innerHTML = "Read less";
            moreText.style.display = "inline";
        }
    }
</script>
<!-- <script>
                const dropdown = document.querySelector('.multi-select-dropdown');
                const selectedOptions = dropdown.querySelector('.selected-options');
                const selectedOptionList = dropdown.querySelector('.selected-option-list');
                const options = dropdown.querySelectorAll('.options li');
                const hiddenInput = dropdown.querySelector('input[type="hidden"]');

                selectedOptions.addEventListener('click', () => {
                    dropdown.classList.toggle('open');
                });

                options.forEach(option => {
                    const checkbox = option.querySelector('input[type="checkbox"]');
                    checkbox.addEventListener('change', () => {
                        if (checkbox.checked) {
                            const selectedOption = document.createElement('div');
                            selectedOption.classList.add('selected-option');
                            selectedOption.textContent = option.textContent;
                            selectedOptionList.appendChild(selectedOption);
                        } else {
                            const selectedOption = selectedOptionList.querySelector(`div[data-value="${option.value}"]`);
                            selectedOption.remove();
                        }
                        const selectedValues = Array.from(options)
                            .filter(option => option.querySelector('input[type="checkbox"]').checked)
                            .map(option => option.querySelector('input[type="checkbox"]').value);
                        hiddenInput.value = selectedValues.join(',');
                    });
                });
            </script> -->
<script>
    const dropdown = document.querySelector('.multi-select-dropdown');
    const selectedOptions = dropdown.querySelector('.selected-options');
    const selectedOptionList = dropdown.querySelector('.selected-option-list');
    const options = dropdown.querySelectorAll('.options li');
    const hiddenInput = dropdown.querySelector('input[type="hidden"]');

    dropdown.addEventListener('click', () => {
        dropdown.classList.toggle('open');
    });
    document.addEventListener('click', (event) => {
        const target = event.target;
        // if (!dropdown.contains(target) && !modal.contains(target)) {

        if (!dropdown.contains(target)) {
            dropdown.classList.remove('open');
        }
    });
    options.forEach(option => {
        const checkbox = option.querySelector('input[type="checkbox"]');

        checkbox.addEventListener('change', () => {
            if (checkbox.checked) {
                document.getElementById('selectop-none').style.display = "none";
                document.getElementById('padding-0').style.padding = "0px";
                // selectedOptionList.style.padding = "0px";

                const selectedOption = document.createElement('div');
                selectedOption.classList.add('selected-option1');
                selectedOption.dataset.value = checkbox.value;
                selectedOption.textContent = checkbox.value;
                selectedOptionList.appendChild(selectedOption);
            } else {
                const selectedOption = selectedOptionList.querySelector(`div[data-value="${checkbox.value}"]`);
                selectedOption.remove();
            }
            const selectedValues = Array.from(options)
                .filter(option => option.querySelector('input[type="checkbox"]').checked)
                .map(option => option.querySelector('input[type="checkbox"]').value);
            hiddenInput.value = selectedValues.join(',');
        });
    });
    //form js
</script>
@endsection
